#pragma once

#include "types.h"
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <optional>

namespace fileengine {

struct FileInfo;
enum class FileType;

class IDatabase {
public:
    virtual ~IDatabase() = default;

    // Connection management
    virtual bool connect() = 0;
    virtual void disconnect() = 0;
    virtual bool is_connected() const = 0;

    // Schema management
    virtual Result<void> create_schema() = 0;
    virtual Result<void> drop_schema() = 0;

    // File metadata operations (using UUIDs instead of paths/ids)
    virtual Result<std::string> insert_file(const std::string& uid, const std::string& name,
                                            const std::string& path, const std::string& parent_uid,
                                            FileType type, const std::string& owner,
                                            int permissions, const std::string& tenant = "") = 0;
    virtual Result<void> update_file_modified(const std::string& uid, const std::string& tenant = "") = 0;
    virtual Result<void> update_file_current_version(const std::string& uid, const std::string& version_timestamp, const std::string& tenant = "") = 0;
    // Update the stored byte size of a file's current content. Non-pure so
    // existing mocks need no change; the concrete Database overrides it.
    virtual Result<void> update_file_size(const std::string& /*uid*/, int64_t /*size*/, const std::string& /*tenant*/ = "") {
        return Result<void>::ok();
    }
    virtual Result<bool> delete_file(const std::string& uid, const std::string& tenant = "") = 0;
    virtual Result<bool> undelete_file(const std::string& uid, const std::string& tenant = "") = 0;
    virtual Result<std::optional<FileInfo>> get_file_by_uid(const std::string& uid, const std::string& tenant = "") = 0;
    virtual Result<std::optional<FileInfo>> get_file_by_path(const std::string& path, const std::string& tenant = "") = 0;  // Keep for backward compatibility
    virtual Result<void> update_file_name(const std::string& uid, const std::string& new_name, const std::string& tenant = "") = 0;
    virtual Result<std::vector<FileInfo>> list_files_in_directory(const std::string& parent_uid, const std::string& tenant = "") = 0;
    virtual Result<std::vector<FileInfo>> list_files_in_directory_with_deleted(const std::string& parent_uid, const std::string& tenant = "") = 0;
    virtual Result<std::vector<FileInfo>> list_all_files(const std::string& tenant = "") = 0;
    virtual Result<std::optional<FileInfo>> get_file_by_name_and_parent(const std::string& name, const std::string& parent_uid, const std::string& tenant = "") = 0;
    virtual Result<std::optional<FileInfo>> get_file_by_name_and_parent_include_deleted(const std::string& name, const std::string& parent_uid, const std::string& tenant = "") = 0;
    virtual Result<int64_t> get_file_size(const std::string& file_uid, const std::string& tenant = "") = 0;
    virtual Result<int64_t> get_directory_size(const std::string& dir_uid, const std::string& tenant = "") = 0;
    virtual Result<std::optional<FileInfo>> get_file_by_uid_include_deleted(const std::string& uid, const std::string& tenant = "") = 0;
    virtual Result<void> update_file_parent(const std::string& uid, const std::string& new_parent_uid, const std::string& tenant = "") = 0;

    // Path-to-UUID mapping (for backward compatibility)
    virtual Result<std::string> path_to_uid(const std::string& path, const std::string& tenant = "") = 0;
    virtual Result<std::vector<std::string>> uid_to_path(const std::string& uid, const std::string& tenant = "") = 0;

    // Version operations (using UUIDs and timestamp strings)
    virtual Result<int64_t> insert_version(const std::string& file_uid, const std::string& version_timestamp,
                                            int64_t size, const std::string& storage_path, const std::string& tenant = "") = 0;
    virtual Result<std::optional<std::string>> get_version_storage_path(const std::string& file_uid, const std::string& version_timestamp, const std::string& tenant = "") = 0;
    virtual Result<std::vector<std::string>> list_versions(const std::string& file_uid, const std::string& tenant = "") = 0;
    // Remove a single version row for a file. Non-pure so existing mocks need
    // no update; the concrete Database overrides it.
    virtual Result<bool> delete_version(const std::string& /*file_uid*/, const std::string& /*version_timestamp*/, const std::string& /*tenant*/ = "") {
        return Result<bool>::err("delete_version not implemented");
    }

    // Version restoration operations
    virtual Result<bool> restore_to_version(const std::string& file_uid, const std::string& version_timestamp, const std::string& user, const std::string& tenant = "") = 0;

    // Metadata operations (versioned by timestamp)
    virtual Result<void> set_metadata(const std::string& file_uid, const std::string& version_timestamp, const std::string& key, const std::string& value, const std::string& tenant = "") = 0;
    virtual Result<std::optional<std::string>> get_metadata(const std::string& file_uid, const std::string& version_timestamp, const std::string& key, const std::string& tenant = "") = 0;
    virtual Result<std::map<std::string, std::string>> get_all_metadata(const std::string& file_uid, const std::string& version_timestamp, const std::string& tenant = "") = 0;
    virtual Result<void> delete_metadata(const std::string& file_uid, const std::string& version_timestamp, const std::string& key, const std::string& tenant = "") = 0;

    // Direct SQL execution for testing
    virtual Result<void> execute(const std::string& sql, const std::string& tenant = "") = 0;
    virtual Result<std::vector<std::vector<std::string>>> query(const std::string& sql, const std::string& tenant = "") = 0;

    // Cache tracking operations
    virtual Result<void> update_file_access_stats(const std::string& uid, const std::string& user, const std::string& tenant = "") = 0;
    virtual Result<std::vector<std::string>> get_least_accessed_files(int limit = 10, const std::string& tenant = "") = 0;
    virtual Result<std::vector<std::string>> get_infrequently_accessed_files(int days_threshold = 30, const std::string& tenant = "") = 0;
    virtual Result<int64_t> get_storage_usage(const std::string& tenant = "") = 0;
    virtual Result<int64_t> get_storage_capacity(const std::string& tenant = "") = 0;

    // Tenant management operations
    virtual Result<void> create_tenant_schema(const std::string& tenant) = 0;
    virtual Result<bool> tenant_schema_exists(const std::string& tenant) = 0;
    virtual Result<void> cleanup_tenant_data(const std::string& tenant) = 0;
    virtual Result<std::vector<std::string>> list_tenants() = 0;

    // ACL operations
    struct AclEntry {
        std::string resource_uid;
        std::string principal;
        int type;
        int permissions;
        int effect = 0; // 0 = ALLOW, 1 = DENY (matches AclEffect)
    };

    // A pending ACL grant tied to a not-yet-created resource. Used by
    // create_file_with_acls to wrap the file row + all default/inherited
    // ACLs in a single transaction.
    struct AclGrant {
        std::string principal;
        int type;
        int permissions;
        std::string performed_by;
        int effect = 0; // 0 = ALLOW, 1 = DENY
    };

    // Atomic resource creation: insert the file row and apply all ACL grants
    // in a single Postgres transaction. Either everything commits or nothing
    // does — a crash mid-creation can never leave a file without ACLs.
    // See plan §6.2.
    virtual Result<std::string> create_file_with_acls(const std::string& uid,
                                                       const std::string& name,
                                                       const std::string& path,
                                                       const std::string& parent_uid,
                                                       FileType type,
                                                       const std::string& owner,
                                                       int permissions,
                                                       const std::vector<AclGrant>& acl_grants,
                                                       const std::string& tenant = "") = 0;

    // performed_by records who triggered the change in granted_by and the
    // acl_audit table. effect (default 0 = ALLOW) selects which logical row
    // for the (resource, principal, type) tuple is updated — ALLOW and DENY
    // are stored separately so they can coexist for the same principal.
    virtual Result<void> add_acl(const std::string& resource_uid, const std::string& principal,
                                 int type, int permissions,
                                 const std::string& tenant = "",
                                 const std::string& performed_by = "",
                                 int effect = 0) = 0;
    // Clear the bits in `permissions` from the matching ACL row. If the
    // resulting permission bitmask is zero the row is deleted. Pass -1 (all
    // bits set) to fully revoke the principal's row in one call. effect
    // (default 0 = ALLOW) selects which logical row to revoke from.
    virtual Result<void> remove_acl(const std::string& resource_uid, const std::string& principal,
                                    int type, int permissions,
                                    const std::string& tenant = "",
                                    const std::string& performed_by = "",
                                    int effect = 0) = 0;
    virtual Result<std::vector<AclEntry>> get_acls_for_resource(const std::string& resource_uid,
                                                                 const std::string& tenant = "") = 0;
    virtual Result<std::vector<AclEntry>> get_user_acls(const std::string& resource_uid,
                                                        const std::string& principal,
                                                        int type,
                                                        const std::string& tenant = "") = 0;
    // Catalog the distinct CLAIM-type ACL principals ("key=value") defined across
    // the tenant, for an ACL editor's claim type-ahead. `prefix` is a
    // case-insensitive filter ("" = all); `limit` caps results (<= 0 = no cap).
    virtual Result<std::vector<std::string>> list_claims(const std::string& prefix,
                                                         int limit,
                                                         const std::string& tenant = "") = 0;

    // Role management operations
    virtual Result<void> create_role(const std::string& role, const std::string& tenant = "") = 0;
    virtual Result<void> delete_role(const std::string& role, const std::string& tenant = "") = 0;
    virtual Result<void> assign_user_to_role(const std::string& user, const std::string& role,
                                             const std::string& tenant = "") = 0;
    virtual Result<void> remove_user_from_role(const std::string& user, const std::string& role,
                                               const std::string& tenant = "") = 0;
    virtual Result<std::vector<std::string>> get_roles_for_user(const std::string& user,
                                                                const std::string& tenant = "") = 0;
    virtual Result<std::vector<std::string>> get_users_for_role(const std::string& role,
                                                                const std::string& tenant = "") = 0;
    virtual Result<std::vector<std::string>> get_all_roles(const std::string& tenant = "") = 0;
};

} // namespace fileengine