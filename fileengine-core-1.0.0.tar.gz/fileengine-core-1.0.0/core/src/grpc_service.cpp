#include "grpc_service.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <google/protobuf/empty.pb.h>
#include <chrono>
#include <ctime>
#include "fileengine/connection_pool_manager.h"
#include "fileengine/server_logger.h"

namespace fileengine {

namespace {
// The filesystem root may be referenced either as the empty string or as the
// all-zeros UUID. Internally the storage/database layers use the empty string,
// so canonicalize the all-zeros form at the gRPC boundary.
inline std::string canonical_uid(const std::string& uid) {
    static const std::string kZeroUuid = "00000000-0000-0000-0000-000000000000";
    return uid == kZeroUuid ? std::string() : uid;
}
} // namespace

GRPCFileService::GRPCFileService(std::shared_ptr<FileSystem> filesystem,
                                 std::shared_ptr<TenantManager> tenant_manager,
                                 std::shared_ptr<AclManager> acl_manager,
                                 std::unique_ptr<StorageTracker> storage_tracker)
    : filesystem_(filesystem), tenant_manager_(tenant_manager), acl_manager_(acl_manager),
      storage_tracker_(std::move(storage_tracker)) {
}

// Directory operations
grpc::Status GRPCFileService::MakeDirectory(grpc::ServerContext* context,
                                            const fileengine_rpc::MakeDirectoryRequest* request,
                                            fileengine_rpc::MakeDirectoryResponse* response) {
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory called - entering method");
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - parent_uid: '" + request->parent_uid() + "', name: '" + request->name() + "'");

    // Check if server is in read-only mode
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - checking read-only mode");
    if (is_server_in_readonly_mode()) {
        response->set_success(false);
        response->set_error("Server is in read-only mode due to database disconnection");
        SERVER_LOG_ERROR("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
                  "MakeDirectory failed: Server is in read-only mode");
        SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
                  "MakeDirectory - exiting with read-only error");
        return grpc::Status::OK;
    }

    // Get the authentication context
    std::string parent_uid = canonical_uid(request->parent_uid());
    std::string name = request->name();
    auto auth_context = request->auth();
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - extracted request parameters - parent_uid: '" + parent_uid + "', name: '" + name + "'");

    // Determine tenant from auth context
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - getting tenant from auth context");
    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - tenant: '" + tenant + "', user: '" + user + "'");

    // Log the raw auth context for debugging
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - raw auth context - user: '" + auth_context.user() + "', tenant: '" + auth_context.tenant() + "'");

    // Check permissions on parent directory
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - checking permissions for parent_uid: '" + parent_uid + "', empty check: " + (parent_uid.empty() ? "true" : "false"));
    if (!parent_uid.empty() && !validate_user_permissions(parent_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to create directory in this location");
        SERVER_LOG_ERROR("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
                  "MakeDirectory failed: User " + user + " does not have permission to create directory in " + parent_uid);
        SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
                  "MakeDirectory - exiting with permission error");
        return grpc::Status::OK;
    }
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - permission check passed");

    // Call the filesystem to create the directory
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - calling filesystem mkdir with parent_uid: '" + parent_uid + "', name: '" + name + "', tenant: '" + tenant + "', user: '" + user + "'");
    auto result = filesystem_->mkdir(parent_uid, name, user, roles, request->permissions(), tenant);
    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - filesystem mkdir completed, success: " + (result.success ? "true" : "false"));

    if (result.success) {
        response->set_success(true);
        response->set_uid(result.value);
        response->set_error("");
        SERVER_LOG_INFO("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
                 "MakeDirectory successful for parent_uid: " + request->parent_uid() + ", name: " + request->name() + ", UID: " + result.value);
        SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
                  "MakeDirectory - exiting successfully");
    } else {
        response->set_success(false);
        response->set_uid("");
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
                  "MakeDirectory failed to create directory: " + result.error);
        SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
                  "MakeDirectory - exiting with filesystem error: " + result.error);
    }

    SERVER_LOG_DEBUG("GRPCService::MakeDirectory", ServerLogger::getInstance().detailed_log_prefix() +
              "MakeDirectory - returning status OK");
    return grpc::Status::OK;
}

grpc::Status GRPCFileService::RemoveDirectory(grpc::ServerContext* context,
                                              const fileengine_rpc::RemoveDirectoryRequest* request,
                                              fileengine_rpc::RemoveDirectoryResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "RemoveDirectory called for uid: " + request->uid());
    std::string dir_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions before removing
    if (!validate_user_permissions(dir_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to remove directory");
        SERVER_LOG_ERROR("GRPCService", "RemoveDirectory failed: User " + user + " does not have permission to remove directory " + dir_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->rmdir(dir_uid, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "RemoveDirectory failed for uid: " + dir_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "RemoveDirectory successful for uid: " + dir_uid);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::ListDirectory(grpc::ServerContext* context,
                                            const fileengine_rpc::ListDirectoryRequest* request,
                                            fileengine_rpc::ListDirectoryResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "ListDirectory called for uid: " + request->uid());
    std::string dir_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check read permissions on the directory
    if (!validate_user_permissions(dir_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to list directory");
        SERVER_LOG_ERROR("GRPCService", "ListDirectory failed: User " + user + " does not have permission to list directory " + dir_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->listdir(dir_uid, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "ListDirectory failed for uid: " + dir_uid + " with error: " + result.error);
    } else {
        for (const auto& entry : result.value) {
            auto* dir_entry = response->add_entries();
            dir_entry->set_uid(entry.uid);
            dir_entry->set_name(entry.name);
            // Convert internal file type to gRPC file type
            fileengine_rpc::FileType grpc_file_type;
            switch (entry.type) {
                case fileengine::FileType::REGULAR_FILE:
                    grpc_file_type = fileengine_rpc::FileType::REGULAR_FILE;
                    break;
                case fileengine::FileType::DIRECTORY:
                    grpc_file_type = fileengine_rpc::FileType::DIRECTORY;
                    break;
                case fileengine::FileType::SYMLINK:
                    grpc_file_type = fileengine_rpc::FileType::SYMLINK;
                    break;
                default:
                    grpc_file_type = fileengine_rpc::FileType::REGULAR_FILE; // default
                    break;
            }
            dir_entry->set_type(grpc_file_type);
            dir_entry->set_size(entry.size);
            // Internal DirectoryEntry already has int64_t values, so assign directly
            dir_entry->set_created_at(entry.created_at);
            dir_entry->set_modified_at(entry.modified_at);
            dir_entry->set_version_count(entry.version_count);
            dir_entry->set_rendition_count(entry.rendition_count);
        }
        SERVER_LOG_INFO("GRPCService", "ListDirectory successful for uid: " + dir_uid);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::ListDirectoryWithDeleted(grpc::ServerContext* context,
                                                       const fileengine_rpc::ListDirectoryWithDeletedRequest* request,
                                                       fileengine_rpc::ListDirectoryWithDeletedResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "ListDirectoryWithDeleted called for uid: " + request->uid());
    // For now, implement the same as ListDirectory but indicate this functionality would return deleted items too
    std::string dir_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check read permissions on the directory
    if (!validate_user_permissions(dir_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to list directory with deleted items");
        SERVER_LOG_ERROR("GRPCService", "ListDirectoryWithDeleted failed: User " + user + " does not have permission to list directory " + dir_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->listdir_with_deleted(dir_uid, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "ListDirectoryWithDeleted failed for uid: " + dir_uid + " with error: " + result.error);
    } else {
        for (const auto& entry : result.value) {
            auto* dir_entry = response->add_entries();
            dir_entry->set_uid(entry.uid);
            dir_entry->set_name(entry.name);
            // Convert internal file type to gRPC file type
            fileengine_rpc::FileType grpc_file_type;
            switch (entry.type) {
                case fileengine::FileType::REGULAR_FILE:
                    grpc_file_type = fileengine_rpc::FileType::REGULAR_FILE;
                    break;
                case fileengine::FileType::DIRECTORY:
                    grpc_file_type = fileengine_rpc::FileType::DIRECTORY;
                    break;
                case fileengine::FileType::SYMLINK:
                    grpc_file_type = fileengine_rpc::FileType::SYMLINK;
                    break;
                default:
                    grpc_file_type = fileengine_rpc::FileType::REGULAR_FILE; // default
                    break;
            }
            dir_entry->set_type(grpc_file_type);
            dir_entry->set_size(entry.size);
            // Internal DirectoryEntry already has int64_t values, so assign directly
            dir_entry->set_created_at(entry.created_at);
            dir_entry->set_modified_at(entry.modified_at);
            dir_entry->set_version_count(entry.version_count);
            dir_entry->set_rendition_count(entry.rendition_count);
        }
        SERVER_LOG_INFO("GRPCService", "ListDirectoryWithDeleted successful for uid: " + dir_uid);
    }

    return grpc::Status::OK;
}

// File operations
grpc::Status GRPCFileService::Touch(grpc::ServerContext* context,
                                   const fileengine_rpc::TouchRequest* request,
                                   fileengine_rpc::TouchResponse* response) {
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch called - entering method");
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - parent_uid: '" + request->parent_uid() + "', name: '" + request->name() + "'");

    // Check if server is in read-only mode
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - checking read-only mode");
    if (is_server_in_readonly_mode()) {
        response->set_success(false);
        response->set_error("Server is in read-only mode due to database disconnection");
        SERVER_LOG_ERROR("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
                  "Touch failed: Server is in read-only mode");
        SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
                  "Touch - exiting with read-only error");
        return grpc::Status::OK;
    }

    std::string parent_uid = canonical_uid(request->parent_uid());
    std::string name = request->name();
    auto auth_context = request->auth();
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - extracted request parameters - parent_uid: '" + parent_uid + "', name: '" + name + "'");

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - tenant: '" + tenant + "', user: '" + user + "'");

    // Log the raw auth context for debugging
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - raw auth context - user: '" + auth_context.user() + "', tenant: '" + auth_context.tenant() + "'");

    // Check permissions on parent directory
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - checking permissions for parent_uid: '" + parent_uid + "', empty check: " + (parent_uid.empty() ? "true" : "false"));
    if (!parent_uid.empty() && !validate_user_permissions(parent_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to create file in this directory");
        SERVER_LOG_ERROR("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
                  "Touch failed: User " + user + " does not have permission to create file in directory " + parent_uid);
        SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
                  "Touch - exiting with permission error");
        return grpc::Status::OK;
    }
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - permission check passed");

    // Call the filesystem to create the file
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - calling filesystem touch with parent_uid: '" + parent_uid + "', name: '" + name + "', tenant: '" + tenant + "', user: '" + user + "'");
    auto result = filesystem_->touch(parent_uid, name, user, roles, tenant);
    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - filesystem touch completed, success: " + (result.success ? "true" : "false"));

    response->set_success(result.success);
    if (result.success) {
        response->set_uid(result.value);
        response->set_error("");
        SERVER_LOG_INFO("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
                 "Touch successful for parent_uid: " + parent_uid + ", name: " + name + ", UID: " + result.value);
        SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
                  "Touch - exiting successfully");
    } else {
        response->set_uid("");
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
                  "Touch failed for parent_uid: " + parent_uid + ", name: " + name + " with error: " + result.error);
        SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
                  "Touch - exiting with filesystem error: " + result.error);
    }

    SERVER_LOG_DEBUG("GRPCService::Touch", ServerLogger::getInstance().detailed_log_prefix() +
              "Touch - returning status OK");
    return grpc::Status::OK;
}

grpc::Status GRPCFileService::RemoveFile(grpc::ServerContext* context,
                                        const fileengine_rpc::RemoveFileRequest* request,
                                        fileengine_rpc::RemoveFileResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "RemoveFile called for uid: " + request->uid());
    // Check if server is in read-only mode
    if (is_server_in_readonly_mode()) {
        response->set_success(false);
        response->set_error("Server is in read-only mode due to database disconnection");
        SERVER_LOG_ERROR("GRPCService", "RemoveFile failed: Server is in read-only mode");
        return grpc::Status::OK;
    }

    std::string file_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions on the file
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to remove file");
        SERVER_LOG_ERROR("GRPCService", "RemoveFile failed: User " + user + " does not have permission to remove file " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->remove(file_uid, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "RemoveFile failed for uid: " + file_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "RemoveFile successful for uid: " + file_uid);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::UndeleteFile(grpc::ServerContext* context,
                                          const fileengine_rpc::UndeleteFileRequest* request,
                                          fileengine_rpc::UndeleteFileResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "UndeleteFile called for uid: " + request->uid());
    std::string file_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // For now, we'll just check if the user has permission to write in the directory
    // In a real implementation, there would be a special undelete permission check
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to undelete file");
        SERVER_LOG_ERROR("GRPCService", "UndeleteFile failed: User " + user + " does not have permission to undelete file " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->undelete(file_uid, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "UndeleteFile failed for uid: " + file_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "UndeleteFile successful for uid: " + file_uid);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::PutFile(grpc::ServerContext* context,
                                     const fileengine_rpc::PutFileRequest* request,
                                     fileengine_rpc::PutFileResponse* response) {
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile called - entering method");
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - file_uid: '" + request->uid() + "', data size: " + std::to_string(request->data().size()));

    // Check if server is in read-only mode
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - checking read-only mode");
    if (is_server_in_readonly_mode()) {
        response->set_success(false);
        response->set_error("Server is in read-only mode due to database disconnection");
        SERVER_LOG_ERROR("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
                  "PutFile failed: Server is in read-only mode");
        SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
                  "PutFile - exiting with read-only error");
        return grpc::Status::OK;
    }

    std::string file_uid = canonical_uid(request->uid());
    auto file_data = request->data();
    auto auth_context = request->auth();
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - extracted request parameters - file_uid: '" + file_uid + "', data size: " + std::to_string(file_data.size()));

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - tenant: '" + tenant + "', user: '" + user + "'");

    // Log the raw auth context for debugging
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - raw auth context - user: '" + auth_context.user() + "', tenant: '" + auth_context.tenant() + "'");

    // Check permissions - user needs write access to the file
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - checking permissions for file_uid: '" + file_uid + "'");
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to write to file");
        SERVER_LOG_ERROR("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
                  "PutFile failed: User " + user + " does not have permission to write to file " + file_uid);
        SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
                  "PutFile - exiting with permission error");
        return grpc::Status::OK;
    }
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - permission check passed");

    // Convert bytes to std::vector<uint8_t>
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - converting data to vector, size: " + std::to_string(file_data.size()));
    std::vector<uint8_t> data_vec(file_data.begin(), file_data.end());

    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - calling filesystem put with file_uid: '" + file_uid + "', tenant: '" + tenant + "', user: '" + user + "'");
    auto result = filesystem_->put(file_uid, data_vec, user, roles, tenant);
    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - filesystem put completed, success: " + (result.success ? "true" : "false"));

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
                  "PutFile failed for uid: " + file_uid + " with error: " + result.error);
        SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
                  "PutFile - exiting with filesystem error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
                 "PutFile successful for uid: " + file_uid);
        SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
                  "PutFile - exiting successfully");
    }

    SERVER_LOG_DEBUG("GRPCService::PutFile", ServerLogger::getInstance().detailed_log_prefix() +
              "PutFile - returning status OK");
    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetFile(grpc::ServerContext* context,
                                     const fileengine_rpc::GetFileRequest* request,
                                     fileengine_rpc::GetFileResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetFile called for uid: " + request->uid());
    std::string file_uid = canonical_uid(request->uid());
    std::string version_timestamp = request->version_timestamp();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs read access to the file
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to read file");
        SERVER_LOG_ERROR("GRPCService", "GetFile failed: User " + user + " does not have permission to read file " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->get(file_uid, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        response->set_data(std::string(result.value.begin(), result.value.end()));
        response->set_error("");
        SERVER_LOG_INFO("GRPCService", "GetFile successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetFile failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

// File information operations
grpc::Status GRPCFileService::Stat(grpc::ServerContext* context,
                                  const fileengine_rpc::StatRequest* request,
                                  fileengine_rpc::StatResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "Stat called for uid: " + request->uid());
    std::string file_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs read access to stat the file
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to access file information");
        SERVER_LOG_ERROR("GRPCService", "Stat failed: User " + user + " does not have permission to access file information for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->stat(file_uid, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        auto* info = response->mutable_info();
        info->set_uid(result.value.uid);
        info->set_name(result.value.name);
        info->set_parent_uid(result.value.parent_uid);
        // Convert internal file type to gRPC file type
        fileengine_rpc::FileType grpc_file_type;
        switch (result.value.type) {
            case fileengine::FileType::REGULAR_FILE:
                grpc_file_type = fileengine_rpc::FileType::REGULAR_FILE;
                break;
            case fileengine::FileType::DIRECTORY:
                grpc_file_type = fileengine_rpc::FileType::DIRECTORY;
                break;
            case fileengine::FileType::SYMLINK:
                grpc_file_type = fileengine_rpc::FileType::SYMLINK;
                break;
            default:
                grpc_file_type = fileengine_rpc::FileType::REGULAR_FILE; // default
                break;
        }
        info->set_type(grpc_file_type);
        info->set_size(result.value.size);
        info->set_owner(result.value.owner);
        info->set_permissions(result.value.permissions);
        // Convert time point to timestamp
        info->set_created_at(std::chrono::duration_cast<std::chrono::seconds>(
            result.value.created_at.time_since_epoch()).count());
        info->set_modified_at(std::chrono::duration_cast<std::chrono::seconds>(
            result.value.modified_at.time_since_epoch()).count());
        info->set_version(result.value.version);
        info->set_rendition_count(result.value.rendition_count);
        SERVER_LOG_INFO("GRPCService", "Stat successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "Stat failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::Exists(grpc::ServerContext* context,
                                    const fileengine_rpc::ExistsRequest* request,
                                    fileengine_rpc::ExistsResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "Exists called for uid: " + request->uid());
    std::string file_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);

    auto result = filesystem_->exists(file_uid, tenant);

    response->set_success(result.success);
    if (result.success) {
        response->set_exists(result.value);
        SERVER_LOG_INFO("GRPCService", "Exists successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "Exists failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

// File manipulation operations
grpc::Status GRPCFileService::Rename(grpc::ServerContext* context,
                                    const fileengine_rpc::RenameRequest* request,
                                    fileengine_rpc::RenameResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "Rename called for uid: " + request->uid() + " to " + request->new_name());
    // Check if server is in read-only mode
    if (is_server_in_readonly_mode()) {
        response->set_success(false);
        response->set_error("Server is in read-only mode due to database disconnection");
        SERVER_LOG_ERROR("GRPCService", "Rename failed: Server is in read-only mode");
        return grpc::Status::OK;
    }

    std::string uid = canonical_uid(request->uid());
    std::string new_name = request->new_name();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs write access to rename the file
    if (!validate_user_permissions(uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to rename file");
        SERVER_LOG_ERROR("GRPCService", "Rename failed: User " + user + " does not have permission to rename file " + uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->rename(uid, new_name, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "Rename failed for uid: " + uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "Rename successful for uid: " + uid);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::Move(grpc::ServerContext* context,
                                  const fileengine_rpc::MoveRequest* request,
                                  fileengine_rpc::MoveResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "Move called for source_uid: " + request->source_uid() + " to " + request->destination_parent_uid());
    std::string source_uid = canonical_uid(request->source_uid());
    std::string dest_uid = canonical_uid(request->destination_parent_uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions on source and destination
    if (!validate_user_permissions(source_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to move source file");
        SERVER_LOG_ERROR("GRPCService", "Move failed: User " + user + " does not have permission to move source file " + source_uid);
        return grpc::Status::OK;
    }

    if (!validate_user_permissions(dest_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to move to destination directory");
        SERVER_LOG_ERROR("GRPCService", "Move failed: User " + user + " does not have permission to move to destination directory " + dest_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->move(source_uid, dest_uid, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "Move failed for source_uid: " + source_uid + " to " + dest_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "Move successful for source_uid: " + source_uid + " to " + dest_uid);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::Copy(grpc::ServerContext* context,
                                  const fileengine_rpc::CopyRequest* request,
                                  fileengine_rpc::CopyResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "Copy called for source_uid: " + request->source_uid() + " to " + request->destination_parent_uid());
    std::string source_uid = canonical_uid(request->source_uid());
    std::string dest_uid = canonical_uid(request->destination_parent_uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions on source and destination
    if (!validate_user_permissions(source_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to read source file");
        SERVER_LOG_ERROR("GRPCService", "Copy failed: User " + user + " does not have permission to read source file " + source_uid);
        return grpc::Status::OK;
    }

    if (!validate_user_permissions(dest_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to write to destination directory");
        SERVER_LOG_ERROR("GRPCService", "Copy failed: User " + user + " does not have permission to write to destination directory " + dest_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->copy(source_uid, dest_uid, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "Copy failed for source_uid: " + source_uid + " to " + dest_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "Copy successful for source_uid: " + source_uid + " to " + dest_uid);
    }

    return grpc::Status::OK;
}

// Version operations
grpc::Status GRPCFileService::ListVersions(grpc::ServerContext* context,
                                          const fileengine_rpc::ListVersionsRequest* request,
                                          fileengine_rpc::ListVersionsResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "ListVersions called for uid: " + request->uid());
    std::string file_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs read access to list file versions
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to list file versions");
        SERVER_LOG_ERROR("GRPCService", "ListVersions failed: User " + user + " does not have permission to list file versions for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->list_versions(file_uid, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        for (const auto& version : result.value) {
            response->add_versions(version);
        }
        SERVER_LOG_INFO("GRPCService", "ListVersions successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "ListVersions failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetVersion(grpc::ServerContext* context,
                                        const fileengine_rpc::GetVersionRequest* request,
                                        fileengine_rpc::GetVersionResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetVersion called for uid: " + request->uid() + " with version " + request->version_timestamp());
    std::string file_uid = canonical_uid(request->uid());
    std::string version_timestamp = request->version_timestamp();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs read access to access file version
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to access file version");
        SERVER_LOG_ERROR("GRPCService", "GetVersion failed: User " + user + " does not have permission to access file version for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->get_version(file_uid, version_timestamp, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        response->set_data(std::string(result.value.begin(), result.value.end()));
        SERVER_LOG_INFO("GRPCService", "GetVersion successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetVersion failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::RestoreToVersion(grpc::ServerContext* context,
                                              const fileengine_rpc::RestoreToVersionRequest* request,
                                              fileengine_rpc::RestoreToVersionResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "RestoreToVersion called for uid: " + request->uid() + " with version " + request->version_timestamp());
    std::string file_uid = canonical_uid(request->uid());
    std::string version_timestamp = request->version_timestamp();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs write access to restore to version
    // In some systems, this might be a special permission, but typically requires write access
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to restore to version");
        SERVER_LOG_ERROR("GRPCService", "RestoreToVersion failed: User " + user + " does not have permission to restore to version for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->restore_to_version(file_uid, version_timestamp, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        response->set_restored_version(version_timestamp);
        response->set_error("");
        SERVER_LOG_INFO("GRPCService", "RestoreToVersion successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "RestoreToVersion failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

// Metadata operations
grpc::Status GRPCFileService::SetMetadata(grpc::ServerContext* context,
                                         const fileengine_rpc::SetMetadataRequest* request,
                                         fileengine_rpc::SetMetadataResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "SetMetadata called for uid: " + request->uid() + " with key " + request->key());
    std::string file_uid = canonical_uid(request->uid());
    std::string key = request->key();
    std::string value = request->value();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs write access to set metadata
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to set metadata");
        SERVER_LOG_ERROR("GRPCService", "SetMetadata failed: User " + user + " does not have permission to set metadata for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->set_metadata(file_uid, key, value, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "SetMetadata failed for uid: " + file_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "SetMetadata successful for uid: " + file_uid);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetMetadata(grpc::ServerContext* context,
                                         const fileengine_rpc::GetMetadataRequest* request,
                                         fileengine_rpc::GetMetadataResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetMetadata called for uid: " + request->uid() + " with key " + request->key());
    std::string file_uid = canonical_uid(request->uid());
    std::string key = request->key();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs read access to get metadata
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to get metadata");
        SERVER_LOG_ERROR("GRPCService", "GetMetadata failed: User " + user + " does not have permission to get metadata for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->get_metadata(file_uid, key, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        response->set_value(result.value);
        SERVER_LOG_INFO("GRPCService", "GetMetadata successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetMetadata failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetAllMetadata(grpc::ServerContext* context,
                                            const fileengine_rpc::GetAllMetadataRequest* request,
                                            fileengine_rpc::GetAllMetadataResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetAllMetadata called for uid: " + request->uid());
    std::string file_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs read access to get metadata
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to get metadata");
        SERVER_LOG_ERROR("GRPCService", "GetAllMetadata failed: User " + user + " does not have permission to get metadata for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->get_all_metadata(file_uid, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        for (const auto& [k, v] : result.value) {
            (*response->mutable_metadata())[k] = v;
        }
        SERVER_LOG_INFO("GRPCService", "GetAllMetadata successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetAllMetadata failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::DeleteMetadata(grpc::ServerContext* context,
                                            const fileengine_rpc::DeleteMetadataRequest* request,
                                            fileengine_rpc::DeleteMetadataResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "DeleteMetadata called for uid: " + request->uid() + " with key " + request->key());
    std::string file_uid = canonical_uid(request->uid());
    std::string key = request->key();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs write access to delete metadata
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::WRITE))) { // WRITE permission
        response->set_success(false);
        response->set_error("User does not have permission to delete metadata");
        SERVER_LOG_ERROR("GRPCService", "DeleteMetadata failed: User " + user + " does not have permission to delete metadata for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->delete_metadata(file_uid, key, user, roles, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "DeleteMetadata failed for uid: " + file_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "DeleteMetadata successful for uid: " + file_uid);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetMetadataForVersion(grpc::ServerContext* context,
                                                   const fileengine_rpc::GetMetadataForVersionRequest* request,
                                                   fileengine_rpc::GetMetadataForVersionResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetMetadataForVersion called for uid: " + request->uid() + " with version " + request->version_timestamp());
    std::string file_uid = canonical_uid(request->uid());
    std::string version_timestamp = request->version_timestamp();
    std::string key = request->key();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs read access to get metadata
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to get metadata for version");
        SERVER_LOG_ERROR("GRPCService", "GetMetadataForVersion failed: User " + user + " does not have permission to get metadata for version for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->get_metadata_for_version(file_uid, version_timestamp, key, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        response->set_value(result.value);
        SERVER_LOG_INFO("GRPCService", "GetMetadataForVersion successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetMetadataForVersion failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetAllMetadataForVersion(grpc::ServerContext* context,
                                                      const fileengine_rpc::GetAllMetadataForVersionRequest* request,
                                                      fileengine_rpc::GetAllMetadataForVersionResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetAllMetadataForVersion called for uid: " + request->uid() + " with version " + request->version_timestamp());
    std::string file_uid = canonical_uid(request->uid());
    std::string version_timestamp = request->version_timestamp();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check permissions - user needs read access to get metadata
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::READ))) { // READ permission
        response->set_success(false);
        response->set_error("User does not have permission to get metadata for version");
        SERVER_LOG_ERROR("GRPCService", "GetAllMetadataForVersion failed: User " + user + " does not have permission to get metadata for version for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->get_all_metadata_for_version(file_uid, version_timestamp, user, roles, tenant);

    response->set_success(result.success);
    if (result.success) {
        for (const auto& [k, v] : result.value) {
            (*response->mutable_metadata())[k] = v;
        }
        SERVER_LOG_INFO("GRPCService", "GetAllMetadataForVersion successful for uid: " + file_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetAllMetadataForVersion failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

// ACL operations
grpc::Status GRPCFileService::GrantPermission(grpc::ServerContext* context,
                                             const fileengine_rpc::GrantPermissionRequest* request,
                                             fileengine_rpc::GrantPermissionResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GrantPermission called for resource_uid: " + request->resource_uid() + " for principal " + request->principal());
    std::string resource_uid = canonical_uid(request->resource_uid());
    std::string principal = request->principal();
    // A "role:" prefix designates a role principal; the stored principal is the
    // bare role name so permission checks (which compare ROLE rules against the
    // caller's effective role names) can match it. A "claim:" prefix designates
    // a claim (ABAC) principal; the stored principal is the bare "key=value"
    // matched against the requester's auth claims. Everything else is a user.
    PrincipalType principal_type = PrincipalType::USER;
    if (principal.rfind("role:", 0) == 0) {
        principal_type = PrincipalType::ROLE;
        principal = principal.substr(5);
    } else if (principal.rfind("claim:", 0) == 0) {
        principal_type = PrincipalType::CLAIM;
        principal = principal.substr(6);
    } else if (principal == kEveryoneGroup || principal == "other") {
        // The "everyone" group (legacy alias "other") targets the OTHER catch-all
        // principal — a rule that applies to every user regardless of identity
        // (e.g. a DENY READ to hide a resource from everyone). The principal
        // string is kept as-is; OTHER rules match by type, not by name.
        principal_type = PrincipalType::OTHER;
    }
    fileengine_rpc::Permission permission = request->permission();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Granting/revoking permissions requires the MANAGE_ACL bit on the
    // resource, NOT plain WRITE — otherwise any user with write access could
    // escalate themselves or others. system_admin role bypass is applied
    // inside AclManager::check_permission.
    if (!validate_user_permissions(resource_uid, auth_context, static_cast<int>(Permission::MANAGE_ACL))) {
        response->set_success(false);
        response->set_error("User does not have permission to grant permissions");
        SERVER_LOG_ERROR("GRPCService", "GrantPermission failed: User " + user + " does not have MANAGE_ACL on " + resource_uid);
        return grpc::Status::OK;
    }

    // Convert gRPC Permission to our internal representation
    int converted_permissions;
    switch(permission) {
        case fileengine_rpc::Permission::READ:
            converted_permissions = static_cast<int>(fileengine::Permission::READ);
            break;
        case fileengine_rpc::Permission::WRITE:
            converted_permissions = static_cast<int>(fileengine::Permission::WRITE);
            break;
        case fileengine_rpc::Permission::DELETE:
            converted_permissions = static_cast<int>(fileengine::Permission::DELETE);
            break;
        case fileengine_rpc::Permission::LIST_DELETED:
            converted_permissions = static_cast<int>(fileengine::Permission::LIST_DELETED);
            break;
        case fileengine_rpc::Permission::UNDELETE:
            converted_permissions = static_cast<int>(fileengine::Permission::UNDELETE);
            break;
        case fileengine_rpc::Permission::VIEW_VERSIONS:
            converted_permissions = static_cast<int>(fileengine::Permission::VIEW_VERSIONS);
            break;
        case fileengine_rpc::Permission::RETRIEVE_BACK_VERSION:
            converted_permissions = static_cast<int>(fileengine::Permission::RETRIEVE_BACK_VERSION);
            break;
        case fileengine_rpc::Permission::RESTORE_TO_VERSION:
            converted_permissions = static_cast<int>(fileengine::Permission::RESTORE_TO_VERSION);
            break;
        case fileengine_rpc::Permission::EXECUTE:
            converted_permissions = static_cast<int>(fileengine::Permission::EXECUTE);
            break;
        case fileengine_rpc::Permission::MANAGE_ACL:
            converted_permissions = static_cast<int>(fileengine::Permission::MANAGE_ACL);
            break;
        case fileengine_rpc::Permission::ACL_INHERIT:
            converted_permissions = static_cast<int>(fileengine::Permission::ACL_INHERIT);
            break;
        case fileengine_rpc::Permission::CULL_VERSIONS:
            converted_permissions = static_cast<int>(fileengine::Permission::CULL_VERSIONS);
            break;
        default:
            converted_permissions = static_cast<int>(fileengine::Permission::READ);  // Default to read permission
            break;
    }

    AclEffect rule_effect = (request->effect() == fileengine_rpc::AclEffect::DENY)
                                ? AclEffect::DENY : AclEffect::ALLOW;

    auto result = acl_manager_->grant_permission(resource_uid, principal,
                                                 principal_type,
                                                 converted_permissions, tenant,
                                                 /*performed_by=*/user,
                                                 rule_effect);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GrantPermission failed for resource_uid: " + resource_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "GrantPermission successful for resource_uid: " + resource_uid);
        // Data-governance event: a permission was granted on this resource.
        filesystem_->publish_acl_change(tenant, resource_uid, principal, converted_permissions, user);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetResourceAcls(grpc::ServerContext* context,
                                             const fileengine_rpc::GetResourceAclsRequest* request,
                                             fileengine_rpc::GetResourceAclsResponse* response) {
    (void)context;
    std::string resource_uid = canonical_uid(request->resource_uid());
    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    SERVER_LOG_DEBUG("GRPCService", "GetResourceAcls called for resource_uid: " + resource_uid);

    // Viewing a resource's ACL entries is a privileged operation (the ACL
    // editor), so require MANAGE_ACL — the same bit grant/revoke require.
    if (!validate_user_permissions(resource_uid, auth_context, static_cast<int>(Permission::MANAGE_ACL))) {
        response->set_success(false);
        response->set_error("User does not have permission to view ACLs");
        SERVER_LOG_ERROR("GRPCService", "GetResourceAcls failed: User " + user + " lacks MANAGE_ACL on " + resource_uid);
        return grpc::Status::OK;
    }

    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "GetResourceAcls failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto result = tenant_context->db->get_acls_for_resource(resource_uid, tenant);
    if (!result.success) {
        response->set_success(false);
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetResourceAcls failed: " + result.error);
        return grpc::Status::OK;
    }

    response->set_success(true);
    for (const auto& e : result.value) {
        auto* m = response->add_acls();
        m->set_principal(e.principal);
        m->set_type(e.type);
        m->set_permissions(e.permissions);
        m->set_effect(e.effect);
    }
    return grpc::Status::OK;
}

grpc::Status GRPCFileService::RevokePermission(grpc::ServerContext* context,
                                              const fileengine_rpc::RevokePermissionRequest* request,
                                              fileengine_rpc::RevokePermissionResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "RevokePermission called for resource_uid: " + request->resource_uid() + " for principal " + request->principal());
    std::string resource_uid = canonical_uid(request->resource_uid());
    std::string principal = request->principal();
    // Mirror GrantPermission: "role:" prefix targets a role principal,
    // "claim:" targets a claim (ABAC) principal stored as bare "key=value".
    PrincipalType principal_type = PrincipalType::USER;
    if (principal.rfind("role:", 0) == 0) {
        principal_type = PrincipalType::ROLE;
        principal = principal.substr(5);
    } else if (principal.rfind("claim:", 0) == 0) {
        principal_type = PrincipalType::CLAIM;
        principal = principal.substr(6);
    } else if (principal == kEveryoneGroup || principal == "other") {
        // The "everyone" group (legacy alias "other") targets the OTHER catch-all
        // principal — a rule that applies to every user regardless of identity
        // (e.g. a DENY READ to hide a resource from everyone). The principal
        // string is kept as-is; OTHER rules match by type, not by name.
        principal_type = PrincipalType::OTHER;
    }
    fileengine_rpc::Permission permission = request->permission();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Revoking permissions requires MANAGE_ACL — see GrantPermission above.
    if (!validate_user_permissions(resource_uid, auth_context, static_cast<int>(Permission::MANAGE_ACL))) {
        response->set_success(false);
        response->set_error("User does not have permission to revoke permissions");
        SERVER_LOG_ERROR("GRPCService", "RevokePermission failed: User " + user + " does not have MANAGE_ACL on " + resource_uid);
        return grpc::Status::OK;
    }

    int converted_permissions;
    switch(permission) {
        case fileengine_rpc::Permission::READ:
            converted_permissions = static_cast<int>(fileengine::Permission::READ);
            break;
        case fileengine_rpc::Permission::WRITE:
            converted_permissions = static_cast<int>(fileengine::Permission::WRITE);
            break;
        case fileengine_rpc::Permission::DELETE:
            converted_permissions = static_cast<int>(fileengine::Permission::DELETE);
            break;
        case fileengine_rpc::Permission::LIST_DELETED:
            converted_permissions = static_cast<int>(fileengine::Permission::LIST_DELETED);
            break;
        case fileengine_rpc::Permission::UNDELETE:
            converted_permissions = static_cast<int>(fileengine::Permission::UNDELETE);
            break;
        case fileengine_rpc::Permission::VIEW_VERSIONS:
            converted_permissions = static_cast<int>(fileengine::Permission::VIEW_VERSIONS);
            break;
        case fileengine_rpc::Permission::RETRIEVE_BACK_VERSION:
            converted_permissions = static_cast<int>(fileengine::Permission::RETRIEVE_BACK_VERSION);
            break;
        case fileengine_rpc::Permission::RESTORE_TO_VERSION:
            converted_permissions = static_cast<int>(fileengine::Permission::RESTORE_TO_VERSION);
            break;
        case fileengine_rpc::Permission::EXECUTE:
            converted_permissions = static_cast<int>(fileengine::Permission::EXECUTE);
            break;
        case fileengine_rpc::Permission::MANAGE_ACL:
            converted_permissions = static_cast<int>(fileengine::Permission::MANAGE_ACL);
            break;
        case fileengine_rpc::Permission::ACL_INHERIT:
            converted_permissions = static_cast<int>(fileengine::Permission::ACL_INHERIT);
            break;
        case fileengine_rpc::Permission::CULL_VERSIONS:
            converted_permissions = static_cast<int>(fileengine::Permission::CULL_VERSIONS);
            break;
        default:
            converted_permissions = static_cast<int>(fileengine::Permission::READ);  // Default to read permission
            break;
    }

    AclEffect rule_effect = (request->effect() == fileengine_rpc::AclEffect::DENY)
                                ? AclEffect::DENY : AclEffect::ALLOW;

    auto result = acl_manager_->revoke_permission(resource_uid, principal,
                                                  principal_type,
                                                  converted_permissions, tenant,
                                                  /*performed_by=*/user,
                                                  rule_effect);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "RevokePermission failed for resource_uid: " + resource_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "RevokePermission successful for resource_uid: " + resource_uid);
        // Data-governance event: a permission was revoked on this resource.
        filesystem_->publish_acl_change(tenant, resource_uid, principal, converted_permissions, user);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::CheckPermission(grpc::ServerContext* context,
                                             const fileengine_rpc::CheckPermissionRequest* request,
                                             fileengine_rpc::CheckPermissionResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "CheckPermission called for resource_uid: " + request->resource_uid() + " for user " + request->auth().user());
    std::string resource_uid = canonical_uid(request->resource_uid());
    fileengine_rpc::Permission required_permission = request->required_permission();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    int required_permissions_int;
    switch(required_permission) {
        case fileengine_rpc::Permission::READ:
            required_permissions_int = static_cast<int>(fileengine::Permission::READ);
            break;
        case fileengine_rpc::Permission::WRITE:
            required_permissions_int = static_cast<int>(fileengine::Permission::WRITE);
            break;
        case fileengine_rpc::Permission::DELETE:
            required_permissions_int = static_cast<int>(fileengine::Permission::DELETE);
            break;
        case fileengine_rpc::Permission::LIST_DELETED:
            required_permissions_int = static_cast<int>(fileengine::Permission::LIST_DELETED);
            break;
        case fileengine_rpc::Permission::UNDELETE:
            required_permissions_int = static_cast<int>(fileengine::Permission::UNDELETE);
            break;
        case fileengine_rpc::Permission::VIEW_VERSIONS:
            required_permissions_int = static_cast<int>(fileengine::Permission::VIEW_VERSIONS);
            break;
        case fileengine_rpc::Permission::RETRIEVE_BACK_VERSION:
            required_permissions_int = static_cast<int>(fileengine::Permission::RETRIEVE_BACK_VERSION);
            break;
        case fileengine_rpc::Permission::RESTORE_TO_VERSION:
            required_permissions_int = static_cast<int>(fileengine::Permission::RESTORE_TO_VERSION);
            break;
        case fileengine_rpc::Permission::EXECUTE:
            required_permissions_int = static_cast<int>(fileengine::Permission::EXECUTE);
            break;
        case fileengine_rpc::Permission::MANAGE_ACL:
            required_permissions_int = static_cast<int>(fileengine::Permission::MANAGE_ACL);
            break;
        case fileengine_rpc::Permission::ACL_INHERIT:
            required_permissions_int = static_cast<int>(fileengine::Permission::ACL_INHERIT);
            break;
        case fileengine_rpc::Permission::CULL_VERSIONS:
            required_permissions_int = static_cast<int>(fileengine::Permission::CULL_VERSIONS);
            break;
        default:
            required_permissions_int = static_cast<int>(fileengine::Permission::READ);  // Default to read permission
            break;
    }

    std::map<std::string, std::string> claims = get_claims_from_auth_context(auth_context);
    auto result = acl_manager_->check_permission(resource_uid, user, roles,
                                                 required_permissions_int, tenant, claims);

    response->set_success(result.success);
    if (result.success) {
        response->set_has_permission(result.value);
        SERVER_LOG_INFO("GRPCService", "CheckPermission successful for resource_uid: " + resource_uid);
    } else {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "CheckPermission failed for resource_uid: " + resource_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetEffectivePermissions(grpc::ServerContext* /*context*/,
                                             const fileengine_rpc::GetEffectivePermissionsRequest* request,
                                             fileengine_rpc::GetEffectivePermissionsResponse* response) {
    std::string resource_uid = canonical_uid(request->resource_uid());
    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);
    SERVER_LOG_DEBUG("GRPCService", "GetEffectivePermissions for resource_uid: " + resource_uid +
                     " user: " + user + " claims: " + std::to_string(auth_context.claims_size()));

    // Resolve the full effective permission set for this principal on the
    // resource, evaluating ACLs only (no read/list of the entity). The principal
    // is (user, roles, claims): claims feed CLAIM-type (ABAC) rule matching so an
    // external indexer gets the same decision the filesystem would enforce.
    std::map<std::string, std::string> claims = get_claims_from_auth_context(auth_context);
    auto result = acl_manager_->get_effective_permissions(resource_uid, user, roles, tenant, claims);
    if (!result.success) {
        response->set_success(false);
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetEffectivePermissions failed for " + resource_uid + ": " + result.error);
        return grpc::Status::OK;
    }

    int bits = result.value;
    response->set_success(true);
    response->set_permission_bits(bits);
    // Decompose the internal bit-flag mask into the wire Permission enum.
    auto add = [&](fileengine::Permission flag, fileengine_rpc::Permission p) {
        if (bits & static_cast<int>(flag)) response->add_permissions(p);
    };
    add(fileengine::Permission::READ, fileengine_rpc::READ);
    add(fileengine::Permission::WRITE, fileengine_rpc::WRITE);
    add(fileengine::Permission::DELETE, fileengine_rpc::DELETE);
    add(fileengine::Permission::LIST_DELETED, fileengine_rpc::LIST_DELETED);
    add(fileengine::Permission::UNDELETE, fileengine_rpc::UNDELETE);
    add(fileengine::Permission::VIEW_VERSIONS, fileengine_rpc::VIEW_VERSIONS);
    add(fileengine::Permission::RETRIEVE_BACK_VERSION, fileengine_rpc::RETRIEVE_BACK_VERSION);
    add(fileengine::Permission::RESTORE_TO_VERSION, fileengine_rpc::RESTORE_TO_VERSION);
    add(fileengine::Permission::EXECUTE, fileengine_rpc::EXECUTE);
    add(fileengine::Permission::MANAGE_ACL, fileengine_rpc::MANAGE_ACL);
    add(fileengine::Permission::ACL_INHERIT, fileengine_rpc::ACL_INHERIT);
    add(fileengine::Permission::CULL_VERSIONS, fileengine_rpc::CULL_VERSIONS);

    SERVER_LOG_INFO("GRPCService", "GetEffectivePermissions ok for " + resource_uid +
                    " bits=" + std::to_string(bits));
    return grpc::Status::OK;
}

// Streaming operations for large files
grpc::Status GRPCFileService::StreamFileUpload(grpc::ServerContext* context,
                                              grpc::ServerReader<fileengine_rpc::PutFileRequest>* reader,
                                              fileengine_rpc::PutFileResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "StreamFileUpload called");
    // Check if server is in read-only mode
    if (is_server_in_readonly_mode()) {
        response->set_success(false);
        response->set_error("Server is in read-only mode due to database disconnection");
        SERVER_LOG_ERROR("GRPCService", "StreamFileUpload failed: Server is in read-only mode");
        return grpc::Status::OK;
    }

    // Read the first message for the target uid + auth (the data field, if any,
    // is the first body chunk). Subsequent messages carry only data.
    fileengine_rpc::PutFileRequest first;
    if (!reader->Read(&first)) {
        response->set_success(false);
        response->set_error("No file data received");
        SERVER_LOG_ERROR("GRPCService", "StreamFileUpload failed: No file data received");
        return grpc::Status::OK;
    }
    const std::string file_uid = first.uid();
    const fileengine_rpc::AuthenticationContext auth_context = first.auth();
    if (file_uid.empty()) {
        response->set_success(false);
        response->set_error("No file data received");
        SERVER_LOG_ERROR("GRPCService", "StreamFileUpload failed: missing uid");
        return grpc::Status::OK;
    }

    const std::string tenant = get_tenant_from_auth_context(auth_context);
    const std::string user = get_user_from_auth_context(auth_context);
    const std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Pull body chunks straight from the gRPC stream into the streaming writer —
    // the whole file is never assembled in memory. The first chunk is the data
    // already read above; the rest come from successive Read() calls.
    bool first_pending = true;
    fileengine_rpc::PutFileRequest msg;
    auto next_chunk = [&](std::vector<uint8_t>& out) -> bool {
        out.clear();
        if (first_pending) {
            first_pending = false;
            const std::string& d = first.data();
            out.assign(d.begin(), d.end());
            return true;
        }
        if (!reader->Read(&msg)) return false;
        const std::string& d = msg.data();
        out.assign(d.begin(), d.end());
        return true;
    };

    auto result = filesystem_->put_stream(file_uid, next_chunk, user, roles, tenant);
    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "StreamFileUpload failed for uid: " + file_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "StreamFileUpload successful for uid: " + file_uid);
    }
    return grpc::Status::OK;
}

grpc::Status GRPCFileService::StreamFileDownload(grpc::ServerContext* context,
                                                const fileengine_rpc::GetFileRequest* request,
                                                grpc::ServerWriter<fileengine_rpc::GetFileResponse>* writer) {
    SERVER_LOG_DEBUG("GRPCService", "StreamFileDownload called for uid: " + request->uid());
    std::string file_uid = canonical_uid(request->uid());
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Stream plaintext chunks straight from storage to the client — the whole
    // file is never assembled in memory (get_stream re-validates READ access and
    // handles decrypt/decompress + S3 restore). Each chunk is written as it is
    // produced; a Write() failure (client disconnect) aborts early.
    auto result = filesystem_->get_stream(
        file_uid,
        [&](const uint8_t* p, size_t n) -> bool {
            fileengine_rpc::GetFileResponse response;
            response.set_success(true);
            response.set_data(std::string(reinterpret_cast<const char*>(p), n));
            return writer->Write(response);
        },
        user, roles, tenant);

    if (result.success) {
        SERVER_LOG_INFO("GRPCService", "StreamFileDownload successful for uid: " + file_uid);
    } else {
        // Emit an error frame. NOTE: with GCM the auth tag trails the ciphertext,
        // so a tag failure can surface only after some chunks were already sent;
        // the client treats a success=false frame as "discard what was received".
        fileengine_rpc::GetFileResponse response;
        response.set_success(false);
        response.set_error(result.error);
        writer->Write(response);
        SERVER_LOG_ERROR("GRPCService", "StreamFileDownload failed for uid: " + file_uid + " with error: " + result.error);
    }

    return grpc::Status::OK;
}

// Administrative operations
grpc::Status GRPCFileService::GetStorageUsage(grpc::ServerContext* context,
                                            const fileengine_rpc::StorageUsageRequest* request,
                                            fileengine_rpc::StorageUsageResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetStorageUsage called for tenant: " + request->tenant());
    auto auth_context = request->auth();
    std::string tenant = request->tenant().empty() ? "default" : request->tenant();

    try {
        if (storage_tracker_) {
            fileengine::StorageUsage usage;
            if (tenant == "default" || tenant.empty()) {
                // Get overall storage usage if no specific tenant requested
                usage = storage_tracker_->get_overall_storage_report();
            } else {
                // Get storage usage for specific tenant
                usage = storage_tracker_->get_tenant_usage(tenant);
            }

            response->set_success(true);
            response->set_error("");
            response->set_total_space(usage.total_space_bytes);
            response->set_used_space(usage.used_space_bytes);
            response->set_available_space(usage.available_space_bytes);
            response->set_usage_percentage(usage.usage_percentage);
        } else {
            // Fallback to simulated values if storage tracker is not available
            response->set_success(true);
            response->set_error("");
            response->set_total_space(1024 * 1024 * 1024);  // 1GB
            response->set_used_space(512 * 1024 * 1024);    // 512MB
            response->set_available_space(512 * 1024 * 1024); // 512MB
            response->set_usage_percentage(0.5); // 50%
        }

        SERVER_LOG_INFO("GRPCService", "GetStorageUsage successful for tenant: " + tenant);
    } catch (const std::exception& e) {
        SERVER_LOG_ERROR("GRPCService", "GetStorageUsage failed: " + std::string(e.what()));
        response->set_success(false);
        response->set_error("Failed to get storage usage: " + std::string(e.what()));
        return grpc::Status(grpc::StatusCode::INTERNAL, e.what());
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::PurgeOldVersions(grpc::ServerContext* context,
                                              const fileengine_rpc::PurgeOldVersionsRequest* request,
                                              fileengine_rpc::PurgeOldVersionsResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "PurgeOldVersions called for uid: " + request->uid());
    std::string file_uid = canonical_uid(request->uid());
    int keep_count = request->keep_count();
    auto auth_context = request->auth();

    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Purging old versions permanently destroys data, so it requires the
    // dedicated CULL_VERSIONS permission — WRITE is deliberately insufficient.
    // This permission is never granted by default and must be granted
    // explicitly. system_admin bypass is applied inside check_permission.
    if (!validate_user_permissions(file_uid, auth_context, static_cast<int>(Permission::CULL_VERSIONS))) {
        response->set_success(false);
        response->set_error("User does not have permission to purge old versions (requires CULL_VERSIONS)");
        SERVER_LOG_ERROR("GRPCService", "PurgeOldVersions failed: User " + user + " lacks CULL_VERSIONS to purge old versions for " + file_uid);
        return grpc::Status::OK;
    }

    auto result = filesystem_->purge_old_versions(file_uid, keep_count, tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "PurgeOldVersions failed for uid: " + file_uid + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "PurgeOldVersions successful for uid: " + file_uid + " (keep_count=" + std::to_string(keep_count) + ")");
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::TriggerSync(grpc::ServerContext* context,
                                         const fileengine_rpc::TriggerSyncRequest* request,
                                         fileengine_rpc::TriggerSyncResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "TriggerSync called for tenant: " + request->tenant());
    std::string tenant = request->tenant();
    auto auth_context = request->auth();

    // In a real implementation, we would trigger a sync operation here
    // For this example, we'll just return success to indicate the call was accepted
    response->set_success(true);
    response->set_error("");
    SERVER_LOG_INFO("GRPCService", "TriggerSync successful for tenant: " + tenant);

    return grpc::Status::OK;
}

// Role management implementations
grpc::Status GRPCFileService::CreateRole(grpc::ServerContext* context,
                                       const fileengine_rpc::CreateRoleRequest* request,
                                       fileengine_rpc::CreateRoleResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "CreateRole called for role: " + request->role());

    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Check if user has admin privileges to create roles
    // For now, we'll allow any authenticated user to create roles
    // In a real implementation, you'd check for admin privileges

    // Get the database from the tenant manager
    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "CreateRole failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto role_manager = std::make_shared<RoleManager>(tenant_context->db);
    auto result = role_manager->create_role(request->role(), tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "CreateRole failed for role: " + request->role() + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "CreateRole successful for role: " + request->role());
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::DeleteRole(grpc::ServerContext* context,
                                       const fileengine_rpc::DeleteRoleRequest* request,
                                       fileengine_rpc::DeleteRoleResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "DeleteRole called for role: " + request->role());

    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Get the database from the tenant manager
    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "DeleteRole failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto role_manager = std::make_shared<RoleManager>(tenant_context->db);
    auto result = role_manager->delete_role(request->role(), tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "DeleteRole failed for role: " + request->role() + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "DeleteRole successful for role: " + request->role());
        // Data-governance event: deleting a role revokes its grants from all members.
        filesystem_->publish_role_change(tenant, FileEventType::RoleDeleted,
                                         request->role(), "", user);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::AssignUserToRole(grpc::ServerContext* context,
                                             const fileengine_rpc::AssignUserToRoleRequest* request,
                                             fileengine_rpc::AssignUserToRoleResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "AssignUserToRole called for user: " + request->user() + " to role: " + request->role());

    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Get the database from the tenant manager
    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "AssignUserToRole failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto role_manager = std::make_shared<RoleManager>(tenant_context->db);
    auto result = role_manager->assign_user_to_role(request->user(), request->role(), tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "AssignUserToRole failed for user: " + request->user() + " to role: " + request->role() + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "AssignUserToRole successful for user: " + request->user() + " to role: " + request->role());
        // Data-governance event: role membership grants effective access.
        filesystem_->publish_role_change(tenant, FileEventType::RoleAssigned,
                                         request->role(), request->user(), user);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::RemoveUserFromRole(grpc::ServerContext* context,
                                               const fileengine_rpc::RemoveUserFromRoleRequest* request,
                                               fileengine_rpc::RemoveUserFromRoleResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "RemoveUserFromRole called for user: " + request->user() + " from role: " + request->role());

    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);
    std::string user = get_user_from_auth_context(auth_context);
    std::vector<std::string> roles = get_roles_from_auth_context(auth_context);

    // Get the database from the tenant manager
    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "RemoveUserFromRole failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto role_manager = std::make_shared<RoleManager>(tenant_context->db);
    auto result = role_manager->remove_user_from_role(request->user(), request->role(), tenant);

    response->set_success(result.success);
    if (!result.success) {
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "RemoveUserFromRole failed for user: " + request->user() + " from role: " + request->role() + " with error: " + result.error);
    } else {
        SERVER_LOG_INFO("GRPCService", "RemoveUserFromRole successful for user: " + request->user() + " from role: " + request->role());
        // Data-governance event: removing membership revokes effective access.
        filesystem_->publish_role_change(tenant, FileEventType::RoleMemberRemoved,
                                         request->role(), request->user(), user);
    }

    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetRolesForUser(grpc::ServerContext* context,
                                           const fileengine_rpc::GetRolesForUserRequest* request,
                                           fileengine_rpc::GetRolesForUserResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetRolesForUser called for user: " + request->user());

    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);

    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "GetRolesForUser failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto role_manager = std::make_shared<RoleManager>(tenant_context->db);
    auto result = role_manager->get_roles_for_user(request->user(), tenant);

    if (!result.success) {
        response->set_success(false);
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetRolesForUser failed for user " + request->user() + ": " + result.error);
        return grpc::Status::OK;
    }

    response->set_success(true);
    for (const auto& r : result.value) {
        response->add_roles(r);
    }
    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetUsersForRole(grpc::ServerContext* context,
                                           const fileengine_rpc::GetUsersForRoleRequest* request,
                                           fileengine_rpc::GetUsersForRoleResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetUsersForRole called for role: " + request->role());

    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);

    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "GetUsersForRole failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto role_manager = std::make_shared<RoleManager>(tenant_context->db);
    auto result = role_manager->get_users_for_role(request->role(), tenant);

    if (!result.success) {
        response->set_success(false);
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetUsersForRole failed for role " + request->role() + ": " + result.error);
        return grpc::Status::OK;
    }

    response->set_success(true);
    for (const auto& u : result.value) {
        response->add_users(u);
    }
    return grpc::Status::OK;
}

grpc::Status GRPCFileService::GetAllRoles(grpc::ServerContext* context,
                                        const fileengine_rpc::GetAllRolesRequest* request,
                                        fileengine_rpc::GetAllRolesResponse* response) {
    SERVER_LOG_DEBUG("GRPCService", "GetAllRoles called");

    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);

    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "GetAllRoles failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto role_manager = std::make_shared<RoleManager>(tenant_context->db);
    auto result = role_manager->get_all_roles(tenant);

    if (!result.success) {
        response->set_success(false);
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "GetAllRoles failed: " + result.error);
        return grpc::Status::OK;
    }

    response->set_success(true);
    for (const auto& r : result.value) {
        response->add_roles(r);
    }
    return grpc::Status::OK;
}

grpc::Status GRPCFileService::ListClaims(grpc::ServerContext* context,
                                        const fileengine_rpc::ListClaimsRequest* request,
                                        fileengine_rpc::ListClaimsResponse* response) {
    (void)context;
    SERVER_LOG_DEBUG("GRPCService", "ListClaims called");

    auto auth_context = request->auth();
    std::string tenant = get_tenant_from_auth_context(auth_context);

    auto tenant_context = tenant_manager_->get_tenant_context(tenant);
    if (!tenant_context || !tenant_context->db) {
        response->set_success(false);
        response->set_error("Tenant context not found or database unavailable");
        SERVER_LOG_ERROR("GRPCService", "ListClaims failed: Tenant context not found for tenant: " + tenant);
        return grpc::Status::OK;
    }

    auto result = tenant_context->db->list_claims(request->prefix(), request->limit(), tenant);
    if (!result.success) {
        response->set_success(false);
        response->set_error(result.error);
        SERVER_LOG_ERROR("GRPCService", "ListClaims failed: " + result.error);
        return grpc::Status::OK;
    }

    response->set_success(true);
    for (const auto& c : result.value) {
        response->add_claims(c);
    }
    return grpc::Status::OK;
}

} // namespace fileengine