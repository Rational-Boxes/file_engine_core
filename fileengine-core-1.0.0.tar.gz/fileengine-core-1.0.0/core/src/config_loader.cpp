#include "config_loader.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <memory>
#include <cstdlib>
#include <unistd.h>
#include <algorithm>
#include <cctype>

namespace fileengine {

std::string ConfigLoader::get_env_var(const std::string& var, const std::string& default_val) {
    const char* env_val = std::getenv(var.c_str());
    return env_val ? std::string(env_val) : default_val;
}

// REDDIS_HOST may be a bare host ("localhost") or "host:port". Split off the
// port only when it's an unambiguous host:port (single colon, no scheme/path,
// not an IPv6 literal); otherwise treat the whole value as the host.
static void apply_redis_host(const std::string& value, Config& config) {
    if (value.empty()) return;
    auto colon = value.rfind(':');
    if (colon != std::string::npos && value.find('/') == std::string::npos &&
        value.find(':') == colon) {
        try {
            config.events_redis_port = std::stoi(value.substr(colon + 1));
            config.events_redis_host = value.substr(0, colon);
            return;
        } catch (...) {
            // not a numeric port — fall through and use the whole value as host
        }
    }
    config.events_redis_host = value;
}

// Apply the optional event-queueing keys from a parsed key/value map onto the
// config. The Redis connection uses FILEENGINE_REDIS_* (canonical); the older
// REDDIS_* keys are still honored as a legacy alias and read first so the
// canonical names take precedence when both are present. Host is read before
// port so an explicit *_PORT always wins over a port embedded in *_HOST.
static void apply_events_config(const std::map<std::string, std::string>& vars, Config& config) {
    auto get = [&](const char* k) -> const std::string* {
        auto it = vars.find(k);
        return it == vars.end() ? nullptr : &it->second;
    };
    if (auto v = get("FILEENGINE_EVENTS_ENABLED")) config.events_enabled = (*v == "true" || *v == "1");

    // Connection — legacy REDDIS_* first, canonical FILEENGINE_REDIS_* override.
    if (auto v = get("REDDIS_HOST")) apply_redis_host(*v, config);
    if (auto v = get("FILEENGINE_REDIS_HOST")) apply_redis_host(*v, config);
    if (auto v = get("REDDIS_PORT")) config.events_redis_port = std::stoi(*v);
    if (auto v = get("FILEENGINE_REDIS_PORT")) config.events_redis_port = std::stoi(*v);
    if (auto v = get("REDDIS_PASSWORD")) config.events_redis_password = *v;
    if (auto v = get("FILEENGINE_REDIS_PASSWORD")) config.events_redis_password = *v;
    if (auto v = get("REDDIS_DB")) config.events_redis_db = std::stoi(*v);
    if (auto v = get("FILEENGINE_REDIS_DB")) config.events_redis_db = std::stoi(*v);

    if (auto v = get("FILEENGINE_EVENTS_STREAM")) config.events_stream = *v;
    if (auto v = get("FILEENGINE_EVENTS_STREAM_MAXLEN")) config.events_stream_maxlen = std::stoll(*v);
    if (auto v = get("FILEENGINE_EVENTS_OUTBOX_CAPACITY")) config.events_outbox_capacity = std::stoul(*v);
}

std::map<std::string, std::string> ConfigLoader::parse_env_file(const std::string& filepath) {
    std::map<std::string, std::string> env_vars;
    std::ifstream file(filepath);

    if (!file.is_open()) {
        return env_vars;  // Return empty map if file can't be opened
    }

    std::string line;
    while (std::getline(file, line)) {
        // Skip comments and empty lines
        if (line.empty() || line[0] == '#' || line[0] == ';') {
            continue;
        }

        // Find the first '=' to split key=value
        size_t pos = line.find('=');
        if (pos != std::string::npos) {
            std::string key = line.substr(0, pos);
            std::string value = line.substr(pos + 1);

            // Trim whitespace
            key.erase(0, key.find_first_not_of(" \t\r\n"));
            key.erase(key.find_last_not_of(" \t\r\n") + 1);
            value.erase(0, value.find_first_not_of(" \t\r\n"));
            value.erase(value.find_last_not_of(" \t\r\n") + 1);

            // Remove quotes if present
            if (value.length() >= 2 &&
                ((value.front() == '"' && value.back() == '"') ||
                 (value.front() == '\'' && value.back() == '\''))) {
                value = value.substr(1, value.length() - 2);
            }

            env_vars[key] = value;
        }
    }

    return env_vars;
}

Config ConfigLoader::load_from_file(const std::string& filepath) {
    Config config;
    auto env_vars = parse_env_file(filepath);
    auto it = env_vars.end();

    // Database configuration
    it = env_vars.find("FILEENGINE_PG_HOST");
    if (it != env_vars.end()) config.db_host = it->second;

    it = env_vars.find("FILEENGINE_PG_PORT");
    if (it != env_vars.end()) config.db_port = std::stoi(it->second);

    it = env_vars.find("FILEENGINE_PG_DATABASE");
    if (it != env_vars.end()) config.db_name = it->second;

    it = env_vars.find("FILEENGINE_PG_USER");
    if (it != env_vars.end()) config.db_user = it->second;

    it = env_vars.find("FILEENGINE_PG_PASSWORD");
    if (it != env_vars.end()) config.db_password = it->second;

    // Storage configuration
    it = env_vars.find("FILEENGINE_STORAGE_BASE");
    if (it != env_vars.end()) config.storage_base_path = it->second;

    // Compression and encryption settings
    it = env_vars.find("FILEENGINE_ENCRYPT_DATA");
    if (it != env_vars.end()) config.encrypt_data = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    it = env_vars.find("FILEENGINE_COMPRESS_DATA");
    if (it != env_vars.end()) config.compress_data = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    it = env_vars.find("AT_REST_KEY");
    if (it != env_vars.end()) config.encryption_key = it->second;

    // S3/MinIO configuration
    it = env_vars.find("FILEENGINE_S3_ENDPOINT");
    if (it != env_vars.end()) config.s3_endpoint = it->second;

    it = env_vars.find("FILEENGINE_S3_REGION");
    if (it != env_vars.end()) config.s3_region = it->second;

    it = env_vars.find("FILEENGINE_S3_BUCKET");
    if (it != env_vars.end()) config.s3_bucket = it->second;

    it = env_vars.find("FILEENGINE_S3_ACCESS_KEY");
    if (it != env_vars.end()) config.s3_access_key = it->second;

    it = env_vars.find("FILEENGINE_S3_SECRET_KEY");
    if (it != env_vars.end()) config.s3_secret_key = it->second;

    it = env_vars.find("FILEENGINE_S3_PATH_STYLE");
    if (it != env_vars.end()) config.s3_path_style = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    // Cache configuration
    it = env_vars.find("FILEENGINE_CACHE_THRESHOLD");
    if (it != env_vars.end()) config.cache_threshold = std::stod(it->second);

    it = env_vars.find("FILEENGINE_MAX_CACHE_SIZE_MB");
    if (it != env_vars.end()) config.max_cache_size_mb = std::stoul(it->second);

    it = env_vars.find("FILEENGINE_MULTI_TENANT_ENABLED");
    if (it != env_vars.end()) config.multi_tenant_enabled = (it->second == "true" || it->second == "1");

    // Server configuration - Changed to match .env file
    it = env_vars.find("FILEENGINE_GRPC_HOST");
    if (it != env_vars.end()) config.server_address = it->second;

    it = env_vars.find("FILEENGINE_GRPC_PORT");
    if (it != env_vars.end()) config.server_port = std::stoi(it->second);

    it = env_vars.find("FILEENGINE_HTTP_THREAD_POOL");
    if (it != env_vars.end()) config.thread_pool_size = std::stoi(it->second);

    // Security configuration
    it = env_vars.find("FILEENGINE_ROOT_USER");
    if (it != env_vars.end()) config.root_user_enabled = (it->second == "true" || it->second == "1");

    it = env_vars.find("FILEENGINE_DEFAULT_WORLD_READABLE");
    if (it != env_vars.end()) config.default_world_readable = (it->second == "true" || it->second == "1");

    // Monitoring REST listener
    it = env_vars.find("FILEENGINE_HTTP_METRICS_ENABLED");
    if (it != env_vars.end()) config.http_metrics_enabled = (it->second == "true" || it->second == "1");
    it = env_vars.find("FILEENGINE_HTTP_METRICS_ADDR");
    if (it != env_vars.end()) config.http_metrics_addr = it->second;
    it = env_vars.find("FILEENGINE_HTTP_METRICS_PORT");
    if (it != env_vars.end()) config.http_metrics_port = std::stoi(it->second);
    it = env_vars.find("FILEENGINE_METRICS_TENANT_LABEL");
    if (it != env_vars.end()) config.metrics_tenant_label = (it->second == "true" || it->second == "1");

    // Sync configuration
    it = env_vars.find("FILEENGINE_S3_SYNC_SUPPORT");
    if (it != env_vars.end()) config.sync_enabled = (it->second == "true" || it->second == "minio" || it->second == "s3");

    it = env_vars.find("FILEENGINE_S3_RETRY_SECONDS");
    if (it != env_vars.end()) config.sync_retry_seconds = std::stoi(it->second);

    // Logging configuration
    if (env_vars.count("FILEENGINE_LOG_LEVEL")) config.log_level = env_vars.at("FILEENGINE_LOG_LEVEL");
    if (env_vars.count("FILEENGINE_LOG_FILE_PATH")) config.log_file_path = env_vars.at("FILEENGINE_LOG_FILE_PATH");
    if (env_vars.count("FILEENGINE_LOG_TO_CONSOLE")) config.log_to_console = (env_vars.at("FILEENGINE_LOG_TO_CONSOLE") == "true");
    if (env_vars.count("FILEENGINE_LOG_TO_FILE")) config.log_to_file = (env_vars.at("FILEENGINE_LOG_TO_FILE") == "true");
    if (env_vars.count("FILEENGINE_LOG_ROTATION_SIZE_MB")) config.log_rotation_size_mb = std::stoul(env_vars.at("FILEENGINE_LOG_ROTATION_SIZE_MB"));
    if (env_vars.count("FILEENGINE_LOG_RETENTION_DAYS")) config.log_retention_days = std::stoi(env_vars.at("FILEENGINE_LOG_RETENTION_DAYS"));

    // Event queueing (optional). Redis connection uses the REDDIS_* keys.
    apply_events_config(env_vars, config);

    return config;
}

Config ConfigLoader::load_from_env() {
    Config config;

    // Load from environment variables - use special indicator for unset values
    std::string env_value;

    env_value = get_env_var("FILEENGINE_PG_HOST", ""); // Empty string means not set
    if (!env_value.empty()) config.db_host = env_value;

    env_value = get_env_var("FILEENGINE_PG_PORT", "");
    if (!env_value.empty()) config.db_port = std::stoi(env_value);

    env_value = get_env_var("FILEENGINE_PG_DATABASE", "");
    if (!env_value.empty()) config.db_name = env_value;

    env_value = get_env_var("FILEENGINE_PG_USER", "");
    if (!env_value.empty()) config.db_user = env_value;

    env_value = get_env_var("FILEENGINE_PG_PASSWORD", "");
    if (!env_value.empty()) config.db_password = env_value;

    env_value = get_env_var("FILEENGINE_STORAGE_BASE", "");
    if (!env_value.empty()) config.storage_base_path = env_value;

    env_value = get_env_var("FILEENGINE_ENCRYPT_DATA", "");
    if (!env_value.empty()) config.encrypt_data = (env_value == "true" || env_value == "TRUE" || env_value == "1");

    env_value = get_env_var("FILEENGINE_COMPRESS_DATA", "");
    if (!env_value.empty()) config.compress_data = (env_value == "true" || env_value == "TRUE" || env_value == "1");

    env_value = get_env_var("AT_REST_KEY", "");
    if (!env_value.empty()) config.encryption_key = env_value;

    env_value = get_env_var("FILEENGINE_S3_ENDPOINT", "");
    if (!env_value.empty()) config.s3_endpoint = env_value;

    env_value = get_env_var("FILEENGINE_S3_REGION", "");
    if (!env_value.empty()) config.s3_region = env_value;

    env_value = get_env_var("FILEENGINE_S3_BUCKET", "");
    if (!env_value.empty()) config.s3_bucket = env_value;

    env_value = get_env_var("FILEENGINE_S3_ACCESS_KEY", "");
    if (!env_value.empty()) config.s3_access_key = env_value;

    env_value = get_env_var("FILEENGINE_S3_SECRET_KEY", "");
    if (!env_value.empty()) config.s3_secret_key = env_value;

    env_value = get_env_var("FILEENGINE_S3_PATH_STYLE", "");
    if (!env_value.empty()) config.s3_path_style = (env_value == "true" || env_value == "TRUE" || env_value == "1");

    env_value = get_env_var("FILEENGINE_CACHE_THRESHOLD", "");
    if (!env_value.empty()) config.cache_threshold = std::stod(env_value);

    env_value = get_env_var("FILEENGINE_MAX_CACHE_SIZE_MB", "");
    if (!env_value.empty()) config.max_cache_size_mb = std::stoul(env_value);

    env_value = get_env_var("FILEENGINE_MULTI_TENANT_ENABLED", "");
    if (!env_value.empty()) config.multi_tenant_enabled = (env_value == "true" || env_value == "1");

    // Server configuration - Changed to match .env file
    env_value = get_env_var("FILEENGINE_GRPC_HOST", "");
    if (!env_value.empty()) config.server_address = env_value;

    env_value = get_env_var("FILEENGINE_GRPC_PORT", "");
    if (!env_value.empty()) config.server_port = std::stoi(env_value);

    env_value = get_env_var("FILEENGINE_HTTP_THREAD_POOL", "");
    if (!env_value.empty()) config.thread_pool_size = std::stoi(env_value);

    // Security configuration
    env_value = get_env_var("FILEENGINE_ROOT_USER", "");
    if (!env_value.empty()) config.root_user_enabled = (env_value == "true" || env_value == "1");

    env_value = get_env_var("FILEENGINE_DEFAULT_WORLD_READABLE", "");
    if (!env_value.empty()) config.default_world_readable = (env_value == "true" || env_value == "1");

    // Monitoring REST listener
    env_value = get_env_var("FILEENGINE_HTTP_METRICS_ENABLED", "");
    if (!env_value.empty()) config.http_metrics_enabled = (env_value == "true" || env_value == "1");
    env_value = get_env_var("FILEENGINE_HTTP_METRICS_ADDR", "");
    if (!env_value.empty()) config.http_metrics_addr = env_value;
    env_value = get_env_var("FILEENGINE_HTTP_METRICS_PORT", "");
    if (!env_value.empty()) config.http_metrics_port = std::stoi(env_value);
    env_value = get_env_var("FILEENGINE_METRICS_TENANT_LABEL", "");
    if (!env_value.empty()) config.metrics_tenant_label = (env_value == "true" || env_value == "1");

    // Sync configuration
    env_value = get_env_var("FILEENGINE_S3_SYNC_SUPPORT", "");
    if (!env_value.empty()) config.sync_enabled = (env_value == "true" || env_value == "minio" || env_value == "s3");

    env_value = get_env_var("FILEENGINE_S3_RETRY_SECONDS", "");
    if (!env_value.empty()) config.sync_retry_seconds = std::stoi(env_value);

    env_value = get_env_var("FILEENGINE_S3_SYNC_ON_STARTUP", "");
    if (!env_value.empty()) config.sync_on_startup = (env_value == "true");

    env_value = get_env_var("FILEENGINE_S3_SYNC_ON_DEMAND", "");
    if (!env_value.empty()) config.sync_on_demand = (env_value == "true");

    env_value = get_env_var("FILEENGINE_S3_SYNC_PATTERN", "");
    if (!env_value.empty()) config.sync_pattern = env_value;

    env_value = get_env_var("FILEENGINE_S3_SYNC_BIDIRECTIONAL", "");
    if (!env_value.empty()) config.sync_bidirectional = (env_value == "true");

    // Logging configuration
    env_value = get_env_var("FILEENGINE_LOG_LEVEL", "");
    if (!env_value.empty()) config.log_level = env_value;

    env_value = get_env_var("FILEENGINE_LOG_FILE_PATH", "");
    if (!env_value.empty()) config.log_file_path = env_value;

    env_value = get_env_var("FILEENGINE_LOG_TO_CONSOLE", "");
    if (!env_value.empty()) config.log_to_console = (env_value == "true");

    env_value = get_env_var("FILEENGINE_LOG_TO_FILE", "");
    if (!env_value.empty()) config.log_to_file = (env_value == "true");

    env_value = get_env_var("FILEENGINE_LOG_ROTATION_SIZE_MB", "");
    if (!env_value.empty()) config.log_rotation_size_mb = std::stoul(env_value);

    env_value = get_env_var("FILEENGINE_LOG_RETENTION_DAYS", "");
    if (!env_value.empty()) config.log_retention_days = std::stoi(env_value);

    // Event queueing (optional) from process environment. Collect the keys we
    // care about into a map and reuse the shared applier.
    {
        std::map<std::string, std::string> ev;
        for (const char* key : {"FILEENGINE_EVENTS_ENABLED",
                                "REDDIS_HOST", "REDDIS_PORT", "REDDIS_PASSWORD", "REDDIS_DB",
                                "FILEENGINE_REDIS_HOST", "FILEENGINE_REDIS_PORT",
                                "FILEENGINE_REDIS_PASSWORD", "FILEENGINE_REDIS_DB",
                                "FILEENGINE_EVENTS_STREAM", "FILEENGINE_EVENTS_STREAM_MAXLEN",
                                "FILEENGINE_EVENTS_OUTBOX_CAPACITY"}) {
            const char* v = std::getenv(key);
            if (v && *v) ev[key] = v;
        }
        apply_events_config(ev, config);
    }

    return config;
}

Config ConfigLoader::load_from_cmd_args(int argc, char* argv[]) {
    Config config;

    // Set all values to designated "unset" state initially
    config.db_host.clear();
    config.db_port = -1;  // Use -1 as indicator for unset integer values
    config.db_name.clear();
    config.db_user.clear();
    config.db_password.clear();
    config.storage_base_path.clear();
    config.s3_endpoint.clear();
    config.s3_region.clear();
    config.s3_bucket.clear();
    config.s3_access_key.clear();
    config.s3_secret_key.clear();
    config.server_address.clear();
    config.server_port = -1;
    config.thread_pool_size = -1;

    // Parse command-line arguments
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--config" && i + 1 < argc) {
            // Config file is handled separately in load_config
            ++i;
        } else if (arg == "--db-host" && i + 1 < argc) {
            config.db_host = argv[++i];
        } else if (arg == "--db-port" && i + 1 < argc) {
            config.db_port = std::stoi(argv[++i]);
        } else if (arg == "--db-name" && i + 1 < argc) {
            config.db_name = argv[++i];
        } else if (arg == "--db-user" && i + 1 < argc) {
            config.db_user = argv[++i];
        } else if (arg == "--db-password" && i + 1 < argc) {
            config.db_password = argv[++i];
        } else if (arg == "--storage-path" && i + 1 < argc) {
            config.storage_base_path = argv[++i];
        } else if (arg == "--s3-endpoint" && i + 1 < argc) {
            config.s3_endpoint = argv[++i];
        } else if (arg == "--s3-region" && i + 1 < argc) {
            config.s3_region = argv[++i];
        } else if (arg == "--s3-bucket" && i + 1 < argc) {
            config.s3_bucket = argv[++i];
        } else if (arg == "--s3-access-key" && i + 1 < argc) {
            config.s3_access_key = argv[++i];
        } else if (arg == "--s3-secret-key" && i + 1 < argc) {
            config.s3_secret_key = argv[++i];
        } else if (arg == "--listen-addr" && i + 1 < argc) {
            config.server_address = argv[++i];
        } else if (arg == "--listen-port" && i + 1 < argc) {
            config.server_port = std::stoi(argv[++i]);
        } else if (arg == "--thread-pool-size" && i + 1 < argc) {
            config.thread_pool_size = std::stoi(argv[++i]);
        }
    }

    return config;
}

Config ConfigLoader::load_config(int argc, char* argv[]) {
    Config config;

    // 1. Load from system config file first (lowest priority)
    Config system_config = load_from_file("/etc/fileengine/core.conf");
    config = system_config;  // Start with system config

    // 2. Load from .env file in working directory (overrides system config)
    Config default_file_config = load_from_file(".env");
    auto default_file_vars = parse_env_file(".env");
    auto it = default_file_vars.end();

    // Apply .env file settings (higher priority than system config)
    // Database configuration
    it = default_file_vars.find("FILEENGINE_PG_HOST");
    if (it != default_file_vars.end()) config.db_host = it->second;

    it = default_file_vars.find("FILEENGINE_PG_PORT");
    if (it != default_file_vars.end()) config.db_port = std::stoi(it->second);

    it = default_file_vars.find("FILEENGINE_PG_DATABASE");
    if (it != default_file_vars.end()) config.db_name = it->second;

    it = default_file_vars.find("FILEENGINE_PG_USER");
    if (it != default_file_vars.end()) config.db_user = it->second;

    it = default_file_vars.find("FILEENGINE_PG_PASSWORD");
    if (it != default_file_vars.end()) config.db_password = it->second;

    // Storage configuration
    it = default_file_vars.find("FILEENGINE_STORAGE_BASE");
    if (it != default_file_vars.end()) config.storage_base_path = it->second;

    // Compression and encryption settings
    it = default_file_vars.find("FILEENGINE_ENCRYPT_DATA");
    if (it != default_file_vars.end()) config.encrypt_data = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    it = default_file_vars.find("FILEENGINE_COMPRESS_DATA");
    if (it != default_file_vars.end()) config.compress_data = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    it = default_file_vars.find("AT_REST_KEY");
    if (it != default_file_vars.end()) config.encryption_key = it->second;

    // S3/MinIO configuration
    it = default_file_vars.find("FILEENGINE_S3_ENDPOINT");
    if (it != default_file_vars.end()) config.s3_endpoint = it->second;

    it = default_file_vars.find("FILEENGINE_S3_REGION");
    if (it != default_file_vars.end()) config.s3_region = it->second;

    it = default_file_vars.find("FILEENGINE_S3_BUCKET");
    if (it != default_file_vars.end()) config.s3_bucket = it->second;

    it = default_file_vars.find("FILEENGINE_S3_ACCESS_KEY");
    if (it != default_file_vars.end()) config.s3_access_key = it->second;

    it = default_file_vars.find("FILEENGINE_S3_SECRET_KEY");
    if (it != default_file_vars.end()) config.s3_secret_key = it->second;

    it = default_file_vars.find("FILEENGINE_S3_PATH_STYLE");
    if (it != default_file_vars.end()) config.s3_path_style = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    // Cache configuration
    it = default_file_vars.find("FILEENGINE_CACHE_THRESHOLD");
    if (it != default_file_vars.end()) config.cache_threshold = std::stod(it->second);

    it = default_file_vars.find("FILEENGINE_MAX_CACHE_SIZE_MB");
    if (it != default_file_vars.end()) config.max_cache_size_mb = std::stoul(it->second);

    it = default_file_vars.find("FILEENGINE_MULTI_TENANT_ENABLED");
    if (it != default_file_vars.end()) config.multi_tenant_enabled = (it->second == "true" || it->second == "1");

    // Server configuration - Changed to match .env file
    it = default_file_vars.find("FILEENGINE_GRPC_HOST");
    if (it != default_file_vars.end()) config.server_address = it->second;

    it = default_file_vars.find("FILEENGINE_GRPC_PORT");
    if (it != default_file_vars.end()) config.server_port = std::stoi(it->second);

    it = default_file_vars.find("FILEENGINE_HTTP_THREAD_POOL");
    if (it != default_file_vars.end()) config.thread_pool_size = std::stoi(it->second);

    // Security configuration
    it = default_file_vars.find("FILEENGINE_ROOT_USER");
    if (it != default_file_vars.end()) config.root_user_enabled = (it->second == "true" || it->second == "1");

    it = default_file_vars.find("FILEENGINE_DEFAULT_WORLD_READABLE");
    if (it != default_file_vars.end()) config.default_world_readable = (it->second == "true" || it->second == "1");

    // Monitoring REST listener
    it = default_file_vars.find("FILEENGINE_HTTP_METRICS_ENABLED");
    if (it != default_file_vars.end()) config.http_metrics_enabled = (it->second == "true" || it->second == "1");
    it = default_file_vars.find("FILEENGINE_HTTP_METRICS_ADDR");
    if (it != default_file_vars.end()) config.http_metrics_addr = it->second;
    it = default_file_vars.find("FILEENGINE_HTTP_METRICS_PORT");
    if (it != default_file_vars.end()) config.http_metrics_port = std::stoi(it->second);
    it = default_file_vars.find("FILEENGINE_METRICS_TENANT_LABEL");
    if (it != default_file_vars.end()) config.metrics_tenant_label = (it->second == "true" || it->second == "1");

    // Sync configuration
    it = default_file_vars.find("FILEENGINE_S3_SYNC_SUPPORT");
    if (it != default_file_vars.end()) config.sync_enabled = (it->second == "true" || it->second == "minio" || it->second == "s3");

    it = default_file_vars.find("FILEENGINE_S3_RETRY_SECONDS");
    if (it != default_file_vars.end()) config.sync_retry_seconds = std::stoi(it->second);

    it = default_file_vars.find("FILEENGINE_S3_SYNC_ON_STARTUP");
    if (it != default_file_vars.end()) config.sync_on_startup = (it->second == "true");

    it = default_file_vars.find("FILEENGINE_S3_SYNC_ON_DEMAND");
    if (it != default_file_vars.end()) config.sync_on_demand = (it->second == "true");

    it = default_file_vars.find("FILEENGINE_S3_SYNC_PATTERN");
    if (it != default_file_vars.end()) config.sync_pattern = it->second;

    it = default_file_vars.find("FILEENGINE_S3_SYNC_BIDIRECTIONAL");
    if (it != default_file_vars.end()) config.sync_bidirectional = (it->second == "true");

    // Logging configuration
    if (default_file_vars.count("FILEENGINE_LOG_LEVEL")) config.log_level = default_file_vars.at("FILEENGINE_LOG_LEVEL");
    if (default_file_vars.count("FILEENGINE_LOG_FILE_PATH")) config.log_file_path = default_file_vars.at("FILEENGINE_LOG_FILE_PATH");
    if (default_file_vars.count("FILEENGINE_LOG_TO_CONSOLE")) config.log_to_console = (default_file_vars.at("FILEENGINE_LOG_TO_CONSOLE") == "true");
    if (default_file_vars.count("FILEENGINE_LOG_TO_FILE")) config.log_to_file = (default_file_vars.at("FILEENGINE_LOG_TO_FILE") == "true");
    if (default_file_vars.count("FILEENGINE_LOG_ROTATION_SIZE_MB")) config.log_rotation_size_mb = std::stoul(default_file_vars.at("FILEENGINE_LOG_ROTATION_SIZE_MB"));
    if (default_file_vars.count("FILEENGINE_LOG_RETENTION_DAYS")) config.log_retention_days = std::stoi(default_file_vars.at("FILEENGINE_LOG_RETENTION_DAYS"));

    // Event queueing (optional) from .env
    apply_events_config(default_file_vars, config);

    // 3. Load from config file specified on command line with --config or -c (overrides .env and system config)
    std::string config_file = ".env"; // Default if no --config specified
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if ((arg == "--config" || arg == "-c") && i + 1 < argc) {
            config_file = argv[++i];
        }
    }

    // Load the specified config file
    auto cmdline_file_vars = parse_env_file(config_file.c_str());

    // Apply command-line specified config file settings (higher priority than .env)
    it = cmdline_file_vars.end();

    // Database configuration
    it = cmdline_file_vars.find("FILEENGINE_PG_HOST");
    if (it != cmdline_file_vars.end()) config.db_host = it->second;

    it = cmdline_file_vars.find("FILEENGINE_PG_PORT");
    if (it != cmdline_file_vars.end()) config.db_port = std::stoi(it->second);

    it = cmdline_file_vars.find("FILEENGINE_PG_DATABASE");
    if (it != cmdline_file_vars.end()) config.db_name = it->second;

    it = cmdline_file_vars.find("FILEENGINE_PG_USER");
    if (it != cmdline_file_vars.end()) config.db_user = it->second;

    it = cmdline_file_vars.find("FILEENGINE_PG_PASSWORD");
    if (it != cmdline_file_vars.end()) config.db_password = it->second;

    // Storage configuration
    it = cmdline_file_vars.find("FILEENGINE_STORAGE_BASE");
    if (it != cmdline_file_vars.end()) config.storage_base_path = it->second;

    // Compression and encryption settings
    it = cmdline_file_vars.find("FILEENGINE_ENCRYPT_DATA");
    if (it != cmdline_file_vars.end()) config.encrypt_data = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    it = cmdline_file_vars.find("FILEENGINE_COMPRESS_DATA");
    if (it != cmdline_file_vars.end()) config.compress_data = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    it = cmdline_file_vars.find("AT_REST_KEY");
    if (it != cmdline_file_vars.end()) config.encryption_key = it->second;

    // S3/MinIO configuration
    it = cmdline_file_vars.find("FILEENGINE_S3_ENDPOINT");
    if (it != cmdline_file_vars.end()) config.s3_endpoint = it->second;

    it = cmdline_file_vars.find("FILEENGINE_S3_REGION");
    if (it != cmdline_file_vars.end()) config.s3_region = it->second;

    it = cmdline_file_vars.find("FILEENGINE_S3_BUCKET");
    if (it != cmdline_file_vars.end()) config.s3_bucket = it->second;

    it = cmdline_file_vars.find("FILEENGINE_S3_ACCESS_KEY");
    if (it != cmdline_file_vars.end()) config.s3_access_key = it->second;

    it = cmdline_file_vars.find("FILEENGINE_S3_SECRET_KEY");
    if (it != cmdline_file_vars.end()) config.s3_secret_key = it->second;

    it = cmdline_file_vars.find("FILEENGINE_S3_PATH_STYLE");
    if (it != cmdline_file_vars.end()) config.s3_path_style = (it->second == "true" || it->second == "TRUE" || it->second == "1");

    // Cache configuration
    it = cmdline_file_vars.find("FILEENGINE_CACHE_THRESHOLD");
    if (it != cmdline_file_vars.end()) config.cache_threshold = std::stod(it->second);

    it = cmdline_file_vars.find("FILEENGINE_MAX_CACHE_SIZE_MB");
    if (it != cmdline_file_vars.end()) config.max_cache_size_mb = std::stoul(it->second);

    it = cmdline_file_vars.find("FILEENGINE_MULTI_TENANT_ENABLED");
    if (it != cmdline_file_vars.end()) config.multi_tenant_enabled = (it->second == "true" || it->second == "1");

    // Server configuration - Changed to match .env file
    it = cmdline_file_vars.find("FILEENGINE_GRPC_HOST");
    if (it != cmdline_file_vars.end()) config.server_address = it->second;

    it = cmdline_file_vars.find("FILEENGINE_GRPC_PORT");
    if (it != cmdline_file_vars.end()) config.server_port = std::stoi(it->second);

    it = cmdline_file_vars.find("FILEENGINE_HTTP_THREAD_POOL");
    if (it != cmdline_file_vars.end()) config.thread_pool_size = std::stoi(it->second);

    // Security configuration
    it = cmdline_file_vars.find("FILEENGINE_ROOT_USER");
    if (it != cmdline_file_vars.end()) config.root_user_enabled = (it->second == "true" || it->second == "1");

    it = cmdline_file_vars.find("FILEENGINE_DEFAULT_WORLD_READABLE");
    if (it != cmdline_file_vars.end()) config.default_world_readable = (it->second == "true" || it->second == "1");

    // Monitoring REST listener
    it = cmdline_file_vars.find("FILEENGINE_HTTP_METRICS_ENABLED");
    if (it != cmdline_file_vars.end()) config.http_metrics_enabled = (it->second == "true" || it->second == "1");
    it = cmdline_file_vars.find("FILEENGINE_HTTP_METRICS_ADDR");
    if (it != cmdline_file_vars.end()) config.http_metrics_addr = it->second;
    it = cmdline_file_vars.find("FILEENGINE_HTTP_METRICS_PORT");
    if (it != cmdline_file_vars.end()) config.http_metrics_port = std::stoi(it->second);
    it = cmdline_file_vars.find("FILEENGINE_METRICS_TENANT_LABEL");
    if (it != cmdline_file_vars.end()) config.metrics_tenant_label = (it->second == "true" || it->second == "1");

    // Sync configuration
    it = cmdline_file_vars.find("FILEENGINE_S3_SYNC_SUPPORT");
    if (it != cmdline_file_vars.end()) config.sync_enabled = (it->second == "true" || it->second == "minio" || it->second == "s3");

    it = cmdline_file_vars.find("FILEENGINE_S3_RETRY_SECONDS");
    if (it != cmdline_file_vars.end()) config.sync_retry_seconds = std::stoi(it->second);

    it = cmdline_file_vars.find("FILEENGINE_S3_SYNC_ON_STARTUP");
    if (it != cmdline_file_vars.end()) config.sync_on_startup = (it->second == "true");

    it = cmdline_file_vars.find("FILEENGINE_S3_SYNC_ON_DEMAND");
    if (it != cmdline_file_vars.end()) config.sync_on_demand = (it->second == "true");

    it = cmdline_file_vars.find("FILEENGINE_S3_SYNC_PATTERN");
    if (it != cmdline_file_vars.end()) config.sync_pattern = it->second;

    it = cmdline_file_vars.find("FILEENGINE_S3_SYNC_BIDIRECTIONAL");
    if (it != cmdline_file_vars.end()) config.sync_bidirectional = (it->second == "true");

    // Logging configuration
    if (cmdline_file_vars.count("FILEENGINE_LOG_LEVEL")) config.log_level = cmdline_file_vars.at("FILEENGINE_LOG_LEVEL");
    if (cmdline_file_vars.count("FILEENGINE_LOG_FILE_PATH")) config.log_file_path = cmdline_file_vars.at("FILEENGINE_LOG_FILE_PATH");
    if (cmdline_file_vars.count("FILEENGINE_LOG_TO_CONSOLE")) config.log_to_console = (cmdline_file_vars.at("FILEENGINE_LOG_TO_CONSOLE") == "true");
    if (cmdline_file_vars.count("FILEENGINE_LOG_TO_FILE")) config.log_to_file = (cmdline_file_vars.at("FILEENGINE_LOG_TO_FILE") == "true");
    if (cmdline_file_vars.count("FILEENGINE_LOG_ROTATION_SIZE_MB")) config.log_rotation_size_mb = std::stoul(cmdline_file_vars.at("FILEENGINE_LOG_ROTATION_SIZE_MB"));
    if (cmdline_file_vars.count("FILEENGINE_LOG_RETENTION_DAYS")) config.log_retention_days = std::stoi(cmdline_file_vars.at("FILEENGINE_LOG_RETENTION_DAYS"));

    // Event queueing (optional) from the --config file
    apply_events_config(cmdline_file_vars, config);

    // 4. Load from environment variables (overrides config files)
    Config env_config = load_from_env();
    if (!env_config.db_host.empty() && env_config.db_host != "localhost") config.db_host = env_config.db_host;
    if (env_config.db_port != 5432) config.db_port = env_config.db_port;
    if (!env_config.db_name.empty() && env_config.db_name != "fileengine") config.db_name = env_config.db_name;
    if (!env_config.db_user.empty() && env_config.db_user != "fileengine_user") config.db_user = env_config.db_user;
    if (!env_config.db_password.empty() && env_config.db_password != "fileengine_password") config.db_password = env_config.db_password;
    if (!env_config.storage_base_path.empty() && env_config.storage_base_path != "/tmp/fileengine_storage") config.storage_base_path = env_config.storage_base_path;
    if (env_config.encrypt_data) config.encrypt_data = env_config.encrypt_data;
    if (env_config.compress_data) config.compress_data = env_config.compress_data;
    if (!env_config.encryption_key.empty()) config.encryption_key = env_config.encryption_key;
    if (!env_config.s3_endpoint.empty() && env_config.s3_endpoint != "http://localhost:9000") config.s3_endpoint = env_config.s3_endpoint;
    if (!env_config.s3_region.empty() && env_config.s3_region != "us-east-1") config.s3_region = env_config.s3_region;
    if (!env_config.s3_bucket.empty() && env_config.s3_bucket != "fileengine") config.s3_bucket = env_config.s3_bucket;
    if (!env_config.s3_access_key.empty() && env_config.s3_access_key != "minioadmin") config.s3_access_key = env_config.s3_access_key;
    if (!env_config.s3_secret_key.empty() && env_config.s3_secret_key != "minioadmin") config.s3_secret_key = env_config.s3_secret_key;
    if (!env_config.s3_path_style) config.s3_path_style = env_config.s3_path_style;
    if (env_config.cache_threshold != 0.8) config.cache_threshold = env_config.cache_threshold;
    if (env_config.max_cache_size_mb != 1024) config.max_cache_size_mb = env_config.max_cache_size_mb;
    if (!env_config.multi_tenant_enabled) config.multi_tenant_enabled = env_config.multi_tenant_enabled;
    if (!env_config.server_address.empty() && env_config.server_address != "0.0.0.0") config.server_address = env_config.server_address;
    if (env_config.server_port != 50051) config.server_port = env_config.server_port;
    if (env_config.thread_pool_size != 10) config.thread_pool_size = env_config.thread_pool_size;
    if (env_config.root_user_enabled) config.root_user_enabled = env_config.root_user_enabled;
    if (!env_config.sync_enabled) config.sync_enabled = env_config.sync_enabled;
    if (env_config.sync_retry_seconds != 60) config.sync_retry_seconds = env_config.sync_retry_seconds;
    if (!env_config.sync_on_startup) config.sync_on_startup = env_config.sync_on_startup;
    if (!env_config.sync_on_demand) config.sync_on_demand = env_config.sync_on_demand;
    if (!env_config.sync_pattern.empty() && env_config.sync_pattern != "all") config.sync_pattern = env_config.sync_pattern;
    if (!env_config.sync_bidirectional) config.sync_bidirectional = env_config.sync_bidirectional;
    if (!env_config.secondary_db_host.empty()) config.secondary_db_host = env_config.secondary_db_host;
    if (env_config.secondary_db_port != 5432) config.secondary_db_port = env_config.secondary_db_port;
    if (!env_config.secondary_db_name.empty() && env_config.secondary_db_name != "fileengine_local") config.secondary_db_name = env_config.secondary_db_name;
    if (!env_config.secondary_db_user.empty() && env_config.secondary_db_user != "fileengine_user") config.secondary_db_user = env_config.secondary_db_user;
    if (!env_config.secondary_db_password.empty() && env_config.secondary_db_password != "fileengine_password") config.secondary_db_password = env_config.secondary_db_password;
    if (env_config.log_level != "INFO") config.log_level = env_config.log_level;
    if (env_config.log_file_path != "/tmp/fileengine.log") config.log_file_path = env_config.log_file_path;
    if (!env_config.log_to_console) config.log_to_console = env_config.log_to_console;
    if (env_config.log_to_file) config.log_to_file = env_config.log_to_file;
    if (env_config.log_rotation_size_mb != 10) config.log_rotation_size_mb = env_config.log_rotation_size_mb;
    if (env_config.log_retention_days != 7) config.log_retention_days = env_config.log_retention_days;

    // Event queueing — process-env overrides files (compared against defaults)
    if (env_config.events_enabled) config.events_enabled = true;
    if (env_config.events_redis_host != "localhost") config.events_redis_host = env_config.events_redis_host;
    if (env_config.events_redis_port != 6379) config.events_redis_port = env_config.events_redis_port;
    if (!env_config.events_redis_password.empty()) config.events_redis_password = env_config.events_redis_password;
    if (env_config.events_redis_db != 0) config.events_redis_db = env_config.events_redis_db;
    if (env_config.events_stream != "fileengine:events") config.events_stream = env_config.events_stream;
    if (env_config.events_stream_maxlen != 100000) config.events_stream_maxlen = env_config.events_stream_maxlen;
    if (env_config.events_outbox_capacity != 10000) config.events_outbox_capacity = env_config.events_outbox_capacity;

    // 5. Load from command-line arguments (highest priority)
    Config cmd_config = load_from_cmd_args(argc, argv);
    if (!cmd_config.db_host.empty()) config.db_host = cmd_config.db_host;
    if (cmd_config.db_port != -1) config.db_port = cmd_config.db_port;
    if (!cmd_config.db_name.empty()) config.db_name = cmd_config.db_name;
    if (!cmd_config.db_user.empty()) config.db_user = cmd_config.db_user;
    if (!cmd_config.db_password.empty()) config.db_password = cmd_config.db_password;
    if (!cmd_config.storage_base_path.empty()) config.storage_base_path = cmd_config.storage_base_path;
    if (!cmd_config.s3_endpoint.empty()) config.s3_endpoint = cmd_config.s3_endpoint;
    if (!cmd_config.s3_region.empty()) config.s3_region = cmd_config.s3_region;
    if (!cmd_config.s3_bucket.empty()) config.s3_bucket = cmd_config.s3_bucket;
    if (!cmd_config.s3_access_key.empty()) config.s3_access_key = cmd_config.s3_access_key;
    if (!cmd_config.s3_secret_key.empty()) config.s3_secret_key = cmd_config.s3_secret_key;
    if (!cmd_config.server_address.empty()) config.server_address = cmd_config.server_address;
    if (cmd_config.server_port != -1) config.server_port = cmd_config.server_port;
    if (cmd_config.thread_pool_size != -1) config.thread_pool_size = cmd_config.thread_pool_size;

    return config;
}

} // namespace fileengine